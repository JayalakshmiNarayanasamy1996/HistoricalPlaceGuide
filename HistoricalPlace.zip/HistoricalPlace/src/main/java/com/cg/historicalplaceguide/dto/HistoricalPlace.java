package com.cg.historicalplaceguide.dto;

import java.util.List;

public class HistoricalPlace {

	private String country;
	private String state;
	private String city;
	private String area;
	private List<Guide> guide;
	private ContactPerson contactPerson;

	public HistoricalPlace() {
	}

	public HistoricalPlace(String country, String state, String city, String area, List<Guide> guide,
			ContactPerson contactPerson) {
		super();
		this.country = country;
		this.state = state;
		this.city = city;
		this.area = area;
		this.guide = guide;
		this.contactPerson = contactPerson;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public List<Guide> getGuide() {
		return guide;
	}

	public void setGuide(List<Guide> guide) {
		this.guide = guide;
	}

	public ContactPerson getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(ContactPerson contactPerson) {
		this.contactPerson = contactPerson;
	}

	@Override
	public String toString() {
		return "HistoricalPlace [country=" + country + ", state=" + state + ", city=" + city + ", area=" + area
				+ ", guide=" + guide + ", contactPerson=" + contactPerson + "]";
	}

}
