package com.cg.historicalplaceguide.exception;

public class HistoricalPlaceCityNotFound extends RuntimeException{
	public HistoricalPlaceCityNotFound() {
		
	}
	public HistoricalPlaceCityNotFound(String msg) {
		System.out.println("Historical Place City is Not Found");
	}

		


}
