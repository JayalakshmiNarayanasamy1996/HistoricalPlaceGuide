package com.cg.historicalplaceguide.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.historicalplace.util.DBUtil;
import com.cg.historicalplaceguide.dto.Guide;
import com.cg.historicalplaceguide.dto.HistoricalPlace;

public class HistoricalPlaceRepositoryImpl implements HistoricalPlaceRepository {
	List<HistoricalPlace> historicalPlaceCity;
	List<HistoricalPlace> historicalPlaceArea;
	public HistoricalPlaceRepositoryImpl() {
	}
	public HistoricalPlace save(HistoricalPlace historicalPlace) {
		DBUtil.historicalPlaces.add(historicalPlace);
		return historicalPlace;
	}
	public List<HistoricalPlace> findByHistoricalPlaceCity(String city) {
		historicalPlaceCity = new ArrayList<HistoricalPlace>();
		for (HistoricalPlace histoCity : DBUtil.historicalPlaces) {
			if (histoCity.getCity().equals(city))
				historicalPlaceCity.add(histoCity);}
		return historicalPlaceCity;
	}

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name) {
		historicalPlaceArea = new ArrayList<HistoricalPlace>();
		for (HistoricalPlace historicalPlace : DBUtil.historicalPlaces) {
			for(Guide guide: historicalPlace.getGuide()) {
				if(guide.getName().equals(name)){
					historicalPlaceArea.add(historicalPlace);
				}}}
		return historicalPlaceArea;
	}
	public List<HistoricalPlace> historicalPlaces() {
		return DBUtil.historicalPlaces;
	}}
