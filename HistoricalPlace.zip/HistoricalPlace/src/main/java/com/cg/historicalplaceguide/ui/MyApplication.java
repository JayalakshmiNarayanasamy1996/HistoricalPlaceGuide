package com.cg.historicalplaceguide.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.historicalplaceguide.dto.ContactPerson;
import com.cg.historicalplaceguide.dto.Guide;
import com.cg.historicalplaceguide.dto.HistoricalPlace;
import com.cg.historicalplaceguide.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguide.exception.HistoricalPlaceException;
import com.cg.historicalplaceguide.service.HistoricalPlaceService;
import com.cg.historicalplaceguide.service.HistoricalPlaceServiceImpl;

public class MyApplication {
	static HistoricalPlaceService service;
	Guide guide = new Guide();
	// static ContactPerson contactPerson;

	public static void main(String[] args) throws HistoricalPlaceException {
		service = new HistoricalPlaceServiceImpl();
		Scanner sc = new Scanner(System.in);
		List<Guide> guideList = new ArrayList<Guide>();
		ContactPerson contactPerson = new ContactPerson();

		int choice = 0;
		do {
			printDetails();
			System.out.println("Enter choice: ");
			choice = sc.nextInt();
			switch (choice) {
			case 1:// Add HistoricalPlace
				System.out.println("Enter HistoricalPlace Country: ");
				String country = sc.next();
				System.out.println("Enter HistoricalPlace State: ");
				String state = sc.next();
				System.out.println("Enter HistoricalPlace City: ");
				String city = sc.next();
				System.out.println("Enter HistoricalPlace Area : ");
				String area = sc.next();
				HistoricalPlace historicalPlace = new HistoricalPlace();
				historicalPlace.setCountry(country);
				historicalPlace.setState(state);
				historicalPlace.setCity(city);
				historicalPlace.setArea(area);

				System.out.println("...................................");
				System.out.println("Enter the Guide Details to Register !!!!!!!!!");
				Guide guides = new Guide();
				System.out.println("Enter Guide Name: ");
				String guideName = sc.next();
				System.out.println("Enter Guide MobileNumber: ");
				BigInteger guideMobileNumber = sc.nextBigInteger();
				System.out.println("Enter Guide Country: ");
				String guideCountry = sc.next();
				System.out.println("Enter Guide State: ");
				String guideState = sc.next();
				System.out.println("Enter Guide City: ");
				String guideCity = sc.next();
				System.out.println("Enter Guide Area : ");
				String guideArea = sc.next();
				guides.setName(guideName);
				guides.setMobileNumber(guideMobileNumber);
				guides.setCountry(guideCountry);
				guides.setState(guideState);
				guides.setCity(guideCity);
				guides.setArea(guideArea);
				service.registerGuide(guides);
				System.out.println("GuideName:" + guides.getName());
				System.out.println("GuideMobileNumber:" + guides.getMobileNumber());
				System.out.println("GuideCountry: " + guides.getCountry());
				System.out.println("GuideState: " + guides.getState());
				System.out.println("GuideCity: " + guides.getCity());
				System.out.println("GuideArea: " + guides.getArea());
				guideList.add(guides);

				System.out.println("............................................ ");
				System.out.println("Enter the ContactPerson  to assign the  details to historicalPlace....");
				ContactPerson conPerson = new ContactPerson();
				System.out.println("Enter ContactPerson Name: ");
				String name = sc.next();
				System.out.println("Enter ContactPerson MobileNumber: ");
				BigInteger mobileNumber = sc.nextBigInteger();
				conPerson.setName(name);
				conPerson.setMobileNumber(mobileNumber);
				service.assignContactPerson(conPerson);
				System.out.println("ContactPerson Name: " + conPerson.getName());
				System.out.println("ContactPerson MobileNumber: " + conPerson.getMobileNumber());
				// contactPerson.add(conPerson);
				historicalPlace.setGuide(guideList);
				historicalPlace.setContactPerson(conPerson);
				service.addHistoricalPlace(historicalPlace);
				break;
			case 2:// Show HistoricalPlace Details
				List<HistoricalPlace> HistoricalPlacesShow = service.historicalPlaceDetails();
				for (HistoricalPlace HistoricalData : HistoricalPlacesShow) {
					System.out.println("HistoricalPlace Country: " + HistoricalData.getCountry());
					System.out.println("HistoricalPlace State: " + HistoricalData.getState());
					System.out.println("HistoricalPlace City: " + HistoricalData.getCity());
					System.out.println("HistoricalPlace Area: " + HistoricalData.getArea());
				}
				break;

			case 3: // Register Guide
				System.out.println("Enter Guide Name: ");
				String gName = sc.next();
				System.out.println("Enter Guide MobileNumber: ");
				BigInteger gMobileNumber = sc.nextBigInteger();
				System.out.println("Enter Guide Country: ");
				String gCountry = sc.next();
				System.out.println("Enter Guide State: ");
				String gState = sc.next();
				System.out.println("Enter Guide City: ");
				String gCity = sc.next();
				System.out.println("Enter Guide Area : ");
				String gArea = sc.next();
				Guide guide = new Guide();
				guide.setName(gName);
				guide.setMobileNumber(gMobileNumber);
				guide.setCountry(gCountry);
				guide.setState(gState);
				guide.setCity(gCity);
				guide.setArea(gArea);
				service.registerGuide(guide);
				System.out.println("GuideName:" + guide.getName());
				System.out.println("GuideMobileNumber:" + guide.getMobileNumber());
				System.out.println("GuideCountry: " + guide.getCountry());
				System.out.println("GuideState: " + guide.getState());
				System.out.println("GuideCity: " + guide.getCity());
				System.out.println("GuideArea: " + guide.getArea());
				guideList.add(guide);

				break;
			case 4:// Search Historical Place By City

				System.out.println("Enter HistoricalPlaceCity: ");
				city = sc.next();
				try {
					List<HistoricalPlace> historicalPlaceSearch = service.searchByHistoricalPlaceCity(city);
					for (HistoricalPlace historicalCity : historicalPlaceSearch) {
						System.out.println("Country:" + historicalCity.getCountry());
						System.out.println("State:" + historicalCity.getState());
						System.out.println("Area:" + historicalCity.getArea());
						System.out.println(historicalCity);
					}
				} catch (HistoricalPlaceCityNotFound e) {
					e.printStackTrace();
				}

				break;
			case 5:// Search Historical Place Area By GuideName

				System.out.println("Enter GuideName");
				name = sc.next();
				try {
					List<HistoricalPlace> guideSearch = service.searchHistoricalPlaceAreaByGuideName(name);
					/*Set<HistoricalPlace> uniqueValue = new LinkedHashSet<HistoricalPlace>(guideSearch);
					guideSearch.clear();
					guideSearch.addAll(uniqueValue);*/
					for (HistoricalPlace searchPlace : guideSearch) {
						System.out.println("HistoricalPlaceArea Is:" + searchPlace.getArea());
						System.out.println(searchPlace);
					}
				} catch (HistoricalPlaceException e) {
					e.printStackTrace();
				}
				break;
			}
		} while (choice != 6);
	}// main

	public static void printDetails() {

		System.out.println("1. Add HistoricalPlace ");
		System.out.println("2. Show All Historical Place");
		System.out.println("3. RegisterGuide");
		System.out.println("4. SearchByHistoricalPlaceCity");
		System.out.println("Here some List of  Cities  available using this city to  search historical place details");
		System.out.println(" !.Chennai");
		System.out.println(" !!.Coimbatore");
		System.out.println(" !!!.Bangalore");
		System.out.println("!!!!.Pune");
		System.out.println("!!!!!.Cochin");
		System.out.println("5. SearchHistoricalPlaceAreaByGuideName");
		System.out.println(" Here some Guides  are available using this guide name to search historical place area");
		System.out.println("!.Jaya");
		System.out.println("!!.Sulekha");
		System.out.println("!!!.Hema");
		System.out.println("!!!!.Sirisha");
		System.out.println("!!!!!.Virajitha");
		System.out.println("6. Exit");
	}// print
}// class
