package com.cg.historicalplaceguide.service;

import java.util.List;

import com.cg.historicalplaceguide.dto.ContactPerson;
import com.cg.historicalplaceguide.dto.Guide;
import com.cg.historicalplaceguide.dto.HistoricalPlace;

public interface HistoricalPlaceService {
	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace);

	public List<HistoricalPlace> historicalPlaceDetails();

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city);

	public ContactPerson assignContactPerson(ContactPerson contactPerson);

	public Guide registerGuide(Guide guide);

	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name);

}
