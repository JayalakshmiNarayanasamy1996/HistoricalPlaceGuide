package com.cg.historicalplaceguide.exception;

public class HistoricalPlaceException extends RuntimeException {
	public HistoricalPlaceException() {

	}

	public HistoricalPlaceException(String msg) {
		System.out.println("Guide Name is  Not Found");
	}

}
