package com.cg.historicalplaceguide.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.historicalplace.util.DBUtil;
import com.cg.historicalplaceguide.dao.HistoricalPlaceRepository;
import com.cg.historicalplaceguide.dao.HistoricalPlaceRepositoryImpl;
import com.cg.historicalplaceguide.dto.ContactPerson;
import com.cg.historicalplaceguide.dto.Guide;
import com.cg.historicalplaceguide.dto.HistoricalPlace;
import com.cg.historicalplaceguide.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguide.exception.HistoricalPlaceException;

public class HistoricalPlaceServiceImpl implements HistoricalPlaceService {
	HistoricalPlaceRepository repo;

	public HistoricalPlaceServiceImpl() {
		repo = new HistoricalPlaceRepositoryImpl();
	}

	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) {
		return repo.save(historicalPlace);
	}

	public ContactPerson assignContactPerson(ContactPerson contactPerson) {
		return contactPerson;
	}

	public Guide registerGuide(Guide guides) {
		List<HistoricalPlace> historicalPlaces = new ArrayList<HistoricalPlace>();
		for(HistoricalPlace area :historicalPlaces)
			if(area.getArea().equals(guides.getArea())) {
				area.getGuide().add(guides);
	}
		return guides;
	}

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) {
		List<HistoricalPlace> place = repo.findByHistoricalPlaceCity(city);
		if (place.isEmpty())
			throw new HistoricalPlaceCityNotFound("Historical Place City Not Found");
		// return repo.findByHistoricalPlaceCity(city);
		return place;
	}

	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name) {
		List<HistoricalPlace> area = repo.findHistoricalPlaceAreaByGuideName(name);
		if (area.isEmpty())
			throw new HistoricalPlaceException("Guide Name Not Found ");
		// return repo.findHistoricalPlaceAreaByGuideName(name);
		return area;
	}

	public List<HistoricalPlace> historicalPlaceDetails() {
		return repo.historicalPlaces();
	}
}
