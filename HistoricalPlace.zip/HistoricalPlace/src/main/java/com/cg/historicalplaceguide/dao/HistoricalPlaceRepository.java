package com.cg.historicalplaceguide.dao;

import java.util.List;

import com.cg.historicalplaceguide.dto.ContactPerson;
import com.cg.historicalplaceguide.dto.Guide;
import com.cg.historicalplaceguide.dto.HistoricalPlace;

public interface HistoricalPlaceRepository {

	public HistoricalPlace save(HistoricalPlace historicalPlace);

	public List<HistoricalPlace> findByHistoricalPlaceCity(String city);

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name);

	public List<HistoricalPlace> historicalPlaces();

}
