package com.cg.historicalplaceguide.dto;

import java.math.BigInteger;

public class ContactPerson {
	private String name;
	private BigInteger mobileNumber;
	public ContactPerson() {
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public ContactPerson(String name, BigInteger mobileNumber) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "ContactPerson [name=" + name + ", mobileNumber=" + mobileNumber + "]";
	}
		
	
	
	
}
