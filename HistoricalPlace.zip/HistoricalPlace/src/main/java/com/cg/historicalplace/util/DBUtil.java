package com.cg.historicalplace.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import com.cg.historicalplaceguide.dto.ContactPerson;
import com.cg.historicalplaceguide.dto.Guide;
import com.cg.historicalplaceguide.dto.HistoricalPlace;

public class DBUtil {
	public static List<HistoricalPlace> historicalPlaces = new ArrayList<HistoricalPlace>();
	public static List<Guide> guides = new ArrayList<Guide>();
	public static List<Guide> guideOne = new ArrayList<Guide>();
	public static List<Guide> guideTwo = new ArrayList<Guide>();
	public static List<Guide> guideThree = new ArrayList<Guide>();
	public static List<Guide> guideFour = new ArrayList<Guide>();
	public static List<Guide> guideFive = new ArrayList<Guide>();
	public static List<ContactPerson> contactPersons = new ArrayList<ContactPerson>();
	static ContactPerson contactPersonOne = new ContactPerson("Sonal", new BigInteger("9876543238"));
	static ContactPerson contactPersonTwo = new ContactPerson("Tanaya", new BigInteger("9876543238"));
	static ContactPerson contactPersonThree = new ContactPerson("Nikitha", new BigInteger("9876543238"));
	static ContactPerson contactPersonFour = new ContactPerson("Ruthuja", new BigInteger("9876543238"));
	static ContactPerson contactPersonFive = new ContactPerson("Radhika", new BigInteger("9000023238"));
	static {
		historicalPlaces
				.add(new HistoricalPlace("India", "Tamilnadu", "Chennai", "Valasaravakam", guideOne, contactPersonOne));
		historicalPlaces.add(
				new HistoricalPlace("India", "Tamilnadu", "Coimbatore", "SaibabaColony", guideTwo, contactPersonTwo));
		historicalPlaces.add(
				new HistoricalPlace("India", "Karnataka", "Bangalore", "Brookfield", guideThree, contactPersonThree));
		historicalPlaces
				.add(new HistoricalPlace("India", "Maharastra", "Pune", "Talawade", guideFour, contactPersonFour));
		historicalPlaces
				.add(new HistoricalPlace("India", "Kerala", "Cochin", "Thottilpalam", guideFive, contactPersonFive));
		guideOne.add(new Guide("Jaya", new BigInteger("9537855325"), "India", "Tamilnadu", "Chennai", "Valasaravakam"));
		guideTwo.add(new Guide("Hema", new BigInteger("9565875325"), "India", "Tamilnadu", "Chennai", "Thambaram"));
		guideThree.add(new Guide("Sulekha", new BigInteger("9859554325"), "India", "Maharastra", "Pune", "Talawade"));
		guideFour
				.add(new Guide("Sirisha", new BigInteger("8756384657"), "India", "Telagana", "Hyderabad", "annasilai"));
		guideFive.add(new Guide("Virajitha", new BigInteger("9098703220"), "India", "Telagana", "kadapa", "ramapuram"));
	}

}
