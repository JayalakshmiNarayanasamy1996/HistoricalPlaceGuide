package com.cg.demoonespringcore.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.demoonespringcore.dto.Product;



@Repository("productdao")           //we are create the bean using this @Repository 
public class ProductDaoImpl implements ProductDao {
	public ProductDaoImpl() {
		System.out.println("hiiii");
		
	}
List<Product> productList = new ArrayList<Product>();

	public void save(Product pro) {
    productList.add(pro);		
	}

	public List<Product> showAllProduct() {
		return productList;
	}

}
