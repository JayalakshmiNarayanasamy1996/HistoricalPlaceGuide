package com.cg.demoonespringcore.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan("com.cg.demoonespringcore") //to scan all the packages starting this name

public class JavaConfig {
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
/*	
	
@Bean(name="prod" , autowire=Autowire.BY_TYPE)  //to create the bean we are using @bean annotation
	public Product getProduct() {
	
		Product pro=new Product();
		pro.setId(100);
		pro.setName("ABCD");
		pro.setPrice(1000.00);
		pro.setDescription("Good");
		return pro;
	}
@Bean(name="tran")
public Transaction getTransaction() {
	Transaction t = new Transaction();
	t.setId(10);
	t.setAmount(2000.22);
	t.setDescription("For Product 1");
	return t;
}*/
}
