package com.cg.demoonespringcore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demoonespringcore.dao.ProductDao;
import com.cg.demoonespringcore.dto.Product;
@Service("productService")
public class ProductServiceImpl implements ProductServicee{
	@Autowired // we are using  this to inject the dao class to call the class
	ProductDao productdao;
	public ProductServiceImpl() {
		
	}
	
	public void addProduct(Product prod) {
		productdao.save(prod);
	}
	public List<Product> showAllProduct() {
		return productdao.showAllProduct();
	}
}
