/*package com.cg.demoonespringcore.dto;

public class Item {
	private int id;
	private String nameofShop;
	
	public Item() {
		System.out.println(" Item Constructor....");
		 
	}
	public void getData() {
		System.out.println("In Item");
	}
	public int getId() {
		return id;
	}
	public String getNameofShop() {
		return nameofShop;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setNameofShop(String nameofShop) {
		this.nameofShop = nameofShop;
	}
	@Override
	public String toString() {
		return "Item [id=" + id + ", nameofShop=" + nameofShop + "]";
	}
	public Item(int id, String nameofShop) {
		super();
		this.id = id;
		this.nameofShop = nameofShop;
	}

}
*/