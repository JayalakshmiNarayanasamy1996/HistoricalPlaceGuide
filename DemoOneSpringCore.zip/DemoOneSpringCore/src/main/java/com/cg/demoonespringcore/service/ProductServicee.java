package com.cg.demoonespringcore.service;

import java.util.List;

import com.cg.demoonespringcore.dto.Product;

public interface ProductServicee {
	public void addProduct(Product prod);
	 public List<Product> showAllProduct();
}
