package com.cg.demoonespringcore.ui;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.demoonespringcore.config.JavaConfig;
import com.cg.demoonespringcore.dto.Product;
import com.cg.demoonespringcore.dto.Transaction;
import com.cg.demoonespringcore.service.ProductServicee;
@Component
public class MyTest {
	    @Autowired
	 ProductServicee service;
	 static  ProductServicee productservice;
	
	 
	 @PostConstruct
private void init() {
		productservice = this.service;
		
	}
	 static Product myProduct;

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext app =
				new AnnotationConfigApplicationContext(JavaConfig.class);
	    // app.getBean("prod");

		 myProduct = (Product) app.getBean("prod");
		Transaction myTransaction =(Transaction)app.getBean("tran");
		myProduct.setId(100);
		myProduct.setName("ABCD");
		myProduct.setPrice(10000);
		myProduct.setDescription("Good");
		
		myTransaction.setId(10);
		myTransaction.setAmount(1234.11);
		myTransaction.setDescription("For Product 1001");
		productservice.addProduct(myProduct);
		System.out.println(productservice.showAllProduct());
		
	}
	
		
		
		
		
		
		
		
		//ProductServicee productService = new ProductServiceImpl();
		//ProductServicee productService = app.getBean("productService",ProductServicee.class);
		
	/*	productService.addProduct(myProduct);
		productService.showAllProduct();
		System.out.println(myProduct.toString());
		*/
		/*myProduct.getAllData();
		System.out.println(myProduct);
*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		// Product p =(Product) app.getBean("prod");
		// p.getAllData();

		/*
		 * p.setId(1001); p.setName("TV"); p.setPrice(1000.22);
		 * p.setDescription("Sony..............");
		 */
		/*
		 * Item i = (Item) app.getBean("it"); i.getData();
		 */
	}
