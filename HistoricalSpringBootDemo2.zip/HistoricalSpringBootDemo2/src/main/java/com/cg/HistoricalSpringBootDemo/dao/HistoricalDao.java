package com.cg.HistoricalSpringBootDemo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.HistoricalSpringBootDemo.dto.HistoricalPlace;


/**
 * @Author Jayalakshmi Narayanasamy
 * wrote on 24-05-2019
 * lastModified 25-05-2019
 * Interface class used to declare the methods
 * @returns historical details
 * @exception com.cg.HistoricalSpringBootDemo.exception
 * 
 */


@Repository
public interface HistoricalDao extends JpaRepository<HistoricalPlace, Integer>{
	
	
	public List<HistoricalPlace> findByCity(String city) ;
	
	public HistoricalPlace findByArea(String name);

	@Query("SELECT h FROM  HistoricalPlace h, IN(h.guide) g  WHERE  g.name= :name")
	public List<HistoricalPlace> findAreaByGuideName(@Param("name") String name);
	
	
}
