package com.cg.HistoricalSpringBootDemo.services;

import java.util.List;

import com.cg.HistoricalSpringBootDemo.dto.ContactPerson;
import com.cg.HistoricalSpringBootDemo.dto.Guide;
import com.cg.HistoricalSpringBootDemo.dto.HistoricalPlace;
import com.cg.HistoricalSpringBootDemo.exception.GuideNameNotFound;
import com.cg.HistoricalSpringBootDemo.exception.HistoricalPlaceCityNotFound;
import com.cg.HistoricalSpringBootDemo.exception.HistoricalPlaceException;

public interface HistoricalService {
 
	
	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) throws HistoricalPlaceException;

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound;

	public ContactPerson assignContactPerson(ContactPerson contactPerson)throws HistoricalPlaceException;

	public Guide registerGuide(Guide guide) throws HistoricalPlaceException;

	public List<HistoricalPlace> searchAreaByGuideName(String name) throws GuideNameNotFound;

	
}
