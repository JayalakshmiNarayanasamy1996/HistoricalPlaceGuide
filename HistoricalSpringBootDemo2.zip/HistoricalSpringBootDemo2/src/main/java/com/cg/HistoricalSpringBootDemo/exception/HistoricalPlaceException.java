package com.cg.HistoricalSpringBootDemo.exception;

/**
 * @Author Jayalakshmi Narayanasamy
 * write on 24-05-2019
 * last modified 24-05-2019
 * HistoricalPlaceException will handle the exception
 */
public class HistoricalPlaceException extends RuntimeException{
	
	public  HistoricalPlaceException() {
		
	}
	public  HistoricalPlaceException(String msg) {
		super(msg);
	}

}
