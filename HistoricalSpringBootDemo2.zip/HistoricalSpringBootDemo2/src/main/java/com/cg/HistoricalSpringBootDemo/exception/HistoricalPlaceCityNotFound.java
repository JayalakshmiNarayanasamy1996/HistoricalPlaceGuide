package com.cg.HistoricalSpringBootDemo.exception;

/**
 * @Author JayalakshmiNarayanasamy
 *  lastModified 25-05-2019
 * HistoricalPlaceCityNotFound will handle the exception
 */
public class HistoricalPlaceCityNotFound extends RuntimeException{
	
	public HistoricalPlaceCityNotFound() {
		
	}
	public HistoricalPlaceCityNotFound(String msg) {
		super(msg);
	}

}
