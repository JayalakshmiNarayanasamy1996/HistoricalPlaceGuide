package com.cg.HistoricalSpringBootDemo.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HistoricalSpringBootDemo.dto.Guide;
import com.cg.HistoricalSpringBootDemo.dto.HistoricalPlace;
import com.cg.HistoricalSpringBootDemo.exception.GuideNameNotFound;
import com.cg.HistoricalSpringBootDemo.exception.HistoricalPlaceCityNotFound;
import com.cg.HistoricalSpringBootDemo.exception.HistoricalPlaceException;
import com.cg.HistoricalSpringBootDemo.services.HistoricalService;

/**
 * @Author Jayalakshmi Narayanasamy
 * wrote on 24-05-2019
 * Last Modified 25-05-2019
 * class  controller  which takes input from user and interact with service
 * and takes data from service and give to output
 * @Exception com.cg.HistoricalSpringBootDemo.exception
 * @return historicalPlace 
 */

@RestController
@RequestMapping("/historicalPlace")
public class HistoricalController {
	
	public static final Logger logger = Logger.getLogger(HistoricalController.class);
	@Autowired
	HistoricalService historicalservice;
	@RequestMapping(value="/addHistoricalPlace" ,method=RequestMethod.POST)
	public HistoricalPlace addHistoricalPlace(@ModelAttribute HistoricalPlace historical) {
	 historicalservice.addHistoricalPlace(historical);
		return historical;
	}
	
	/** @author Jayalakshmi Narayanasamy
	 * wrote on 24-05-2019
	 * Last Modified 25-05-2019
	 * @param guide
	 * @return guide
	 * @exception com.cg.HistoricalSpringBootDemo.exception
	 */
	
	
	@RequestMapping(value="/registerGuide" ,method=RequestMethod.POST)
	public ResponseEntity<Guide> registerGuide(@ModelAttribute Guide guide) {
		Guide guides=null;
				try {
					 guides= historicalservice.registerGuide(guide);
				}catch (HistoricalPlaceException e) {
					 return new ResponseEntity("There is no such HistoricalPlace Found For This Guide",HttpStatus.NOT_FOUND);
				}
		return new ResponseEntity<Guide>(guides,HttpStatus.OK);
	}
	
	
	/**@Author  Jayalakshmi Narayanasamy
	 * wrote on 24-05-2019
	 * Last Modified 25-05-2019
	 * @param historicalPlace
	 * @return historicalPlace
	 * @exception com.cg.HistoricalSpringBootDemo.exception
	 */
	
	
	@RequestMapping(value="/searchCity" ,method=RequestMethod.GET)
	public ResponseEntity<List<HistoricalPlace>> searchByHistoricalPlaceCity(@RequestParam("city")String city) {
		List<HistoricalPlace> historicalPlaceList =null;
		try {
		historicalPlaceList=historicalservice.searchByHistoricalPlaceCity(city);
		}catch (HistoricalPlaceCityNotFound e) {
			 return new ResponseEntity("Historical City is Not Found",HttpStatus.NOT_FOUND);
		}
		//if(historicalPlaceList.isEmpty()) {
			return new ResponseEntity<List<HistoricalPlace>>(historicalPlaceList,HttpStatus.OK);
		}
	 
	/**@author Jayalakshmi Narayanasamy
	 * wrote on 24-05-2019
	 * Last Modified 25-05-2019
	 * @param guide
	 * @exception com.cg.HistoricalSpringBootDemo.exception
	 * @return historicalPlace
	 */
	

@RequestMapping(value="/searchArea" ,method=RequestMethod.GET)
public ResponseEntity<List<HistoricalPlace>> searchHistoricalPlaceAreaByGuideName(@RequestParam("name")String name) {
	//HistoricalPlace searchArea =null;
	List<HistoricalPlace>	searchArea =null;
	try{
		searchArea=historicalservice.searchAreaByGuideName(name);
	}catch (GuideNameNotFound e) {
		return new ResponseEntity("Guide Name is Not Found",HttpStatus.NOT_FOUND);
		
	}
	return new ResponseEntity<List<HistoricalPlace>>(searchArea,HttpStatus.OK);
	}
}

			



























			
			
			
			
		
