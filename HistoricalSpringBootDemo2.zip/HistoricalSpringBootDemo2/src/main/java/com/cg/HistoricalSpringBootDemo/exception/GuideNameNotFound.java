package com.cg.HistoricalSpringBootDemo.exception;

/**@Author JayalakshmiNarayanasamy
 *  lastModified 25-05-2019
 * GuideNameNotFound will handle the exception
 */
public class GuideNameNotFound extends RuntimeException{
	public GuideNameNotFound() {
		
	}
	public GuideNameNotFound(String msg) {
		super(msg);
	}

}
