package com.cg.HistoricalSpringBootDemo.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.HistoricalSpringBootDemo.controller.HistoricalController;
import com.cg.HistoricalSpringBootDemo.dao.HistoricalDao;
import com.cg.HistoricalSpringBootDemo.dto.ContactPerson;
import com.cg.HistoricalSpringBootDemo.dto.Guide;
import com.cg.HistoricalSpringBootDemo.dto.HistoricalPlace;
import com.cg.HistoricalSpringBootDemo.exception.GuideNameNotFound;
import com.cg.HistoricalSpringBootDemo.exception.HistoricalPlaceCityNotFound;
import com.cg.HistoricalSpringBootDemo.exception.HistoricalPlaceException;

/**
 * @Author JayalakshmiNarayanasamy write on 24-05-2019 lastModified 25-05-2019
 *         Class used to perform Business Logic.
 */

@Service
public class HistoricalServiceImpl implements HistoricalService {
	@Autowired
	HistoricalDao historicaldao;

	/**
	 * @Author JayalakshmiNarayanasamy wrote on 24-05-2019 lastModified 25-05-2019
	 *         methods addHistoricalPlace add the historical Place
	 * @exception com.cg.HistoricalSpringBootDemo.HistoricalPlaceException
	 * @return HistoricalPlace
	 */

	@Override
	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
		if (HistoricalController.logger.isDebugEnabled()) {
			HistoricalController.logger.debug("addHistoricalPlace (HistoricalPlace) is executed!");
			HistoricalController.logger.debug(" Id \"+h_id+\" set to HistoricalPlace object\"");
		}
		return historicaldao.save(historicalPlace);
	}

	/**
	 * @Author JayalakshmiNarayanasamy 
	 * wrote on 24-05-2019 
	 * lastModified 25-05-2019
	 *         (non-Javadoc)
	 * @see com.cg.HistoricalSpringBootDemo.service.HistoricalPlaceService#assignContactPerson(com.cg.HistoricalSpringBootDemo.dto.ContactPerson)
	 * @exception com.cg.HistoricalSpringBootDemo.HistoricalPlaceException mobile number is same 
	 * @returns ContactPerson
	 */

	@Override
	public ContactPerson assignContactPerson(ContactPerson contactPerson) throws HistoricalPlaceException {
		if (HistoricalController.logger.isDebugEnabled()) {
			HistoricalController.logger.debug("assignContactPerson (HistoricalPlace) is executed!");
			HistoricalController.logger.debug(" MobileNumber \"+mobileNumber+\" set a HistoricalPlace Object \"");
		}

		return contactPerson;
	}

	/**
	 * @Author JayalakshmiNarayanasamy
	 *  wrote on 24-05-2019 
	 *  lastModified 25-05-2019
	 *         (non-Javadoc)
	 * @see com.cg.HistoricalSpringBootDemo.service.HistoricalPlaceService#registerGuide(com.cg.HistoricalSpringBootDemo.dto.Guide)
	 * @exception com.cg.HistoricalSpringBootDemo.HistoricalPlaceException if no  historicalPlace  area data is matched
	 * @param Guide java.lang.String
	 * @returns guides
	 */

	@Override
	public Guide registerGuide(Guide guide) throws HistoricalPlaceException {
		if (HistoricalController.logger.isDebugEnabled()) {
			HistoricalController.logger.debug("registerGuide (HistoricalPlace) is executed!");
			HistoricalController.logger.debug(" City \"+city+\" set to Guide object\"");
		}
		HistoricalPlace hp = historicaldao.findByArea(guide.getArea());
		System.out.println(hp);
		if (hp != null) {
			List<Guide> guideList = new ArrayList<>();
			if (hp.getGuide() != null)
				guideList = hp.getGuide();
			guideList.add(guide);
			hp.setGuide(guideList);
			historicaldao.save(hp);
			return guide;
		}
		HistoricalController.logger.error("Given Data is invalid " + new HistoricalPlaceCityNotFound());
		throw new HistoricalPlaceException("There is no such HistoricalPlace Found for this Guide");
	}

	/**
	 * @Author JayalakshmiNarayanasamy wrote on 24-05-2019 lastModified 25-05-2019
	 *         (non-Javadoc)
	 * @see com.cg.HistoricalSpringBootDemo.service.HistoricalPlaceService#searchByHistoricalPlaceCity(java.lang.String)
	 * @exception com.cg.HistoricalSpringBootDemo.HistoricalPlaceCityNotFound if no matching city is found
	 * @param City java.lang.String
	 * @return List<HistoricalPlace> details
	 */
	@Override
	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound {
		if (HistoricalController.logger.isDebugEnabled()) {
			HistoricalController.logger.debug("searchByHistoricalPlaceCity (HistoricalPlace) is executed!");
			HistoricalController.logger.debug(" City \"+city+\" search to HistoricalPlace object\"");
		}
		List<HistoricalPlace> place = historicaldao.findByCity(city);
		if (place.isEmpty()) {
			HistoricalController.logger.error("Given Data is invalid " + new HistoricalPlaceCityNotFound());
			throw new HistoricalPlaceCityNotFound("Historical Place City Not Found");
		} else {
			return place;
		}

	}

	/**
	 * @Author JayalakshmiNarayanasamy wrote on 24-05-2019 lastModified 21-05-2019
	 *         (non-Javadoc)
	 * @see com.cg.HistoricalSpringBootDemo.service.HistoricalPlaceService#searchHistoricalPlaceAreaByGuideName(java.lang.String)
	 * @exception com.cg.HistoricalSpringBootDemo.HistoricalPlaceException if there is no guide name found
	 * @param GuideName java.lang.String
	 * @returns list of historicalPlace
	 */
	@Override
	public List<HistoricalPlace> searchAreaByGuideName(String name) throws GuideNameNotFound {
		List<HistoricalPlace> area = new ArrayList<HistoricalPlace>();
		if (HistoricalController.logger.isDebugEnabled()) {
			HistoricalController.logger.debug("searchHistoricalPlaceAreaByGuideName (HistoricalPlace) is executed!");
			HistoricalController.logger.debug(" Name \"+name+\" set to HistoricalPlace object\"");
		}
		area = historicaldao.findAreaByGuideName(name);
		if (area.isEmpty()) {
			HistoricalController.logger.error("Given Data is invalid " + new GuideNameNotFound());
			throw new GuideNameNotFound("Guide Name Not Found ");
		}
		return area;

	}
}
