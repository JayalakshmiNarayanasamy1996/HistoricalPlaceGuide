package com.cg.HistoricalSpringBootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(" com.cg.HistoricalSpringBootDemo")
public class HistoricalSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HistoricalSpringBootApplication.class, args);
		System.out.println("Welcome to my HistoricalPlace Application");
	}

}
