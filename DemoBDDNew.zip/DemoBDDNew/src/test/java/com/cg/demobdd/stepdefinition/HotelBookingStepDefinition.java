package com.cg.demobdd.stepdefinition;


import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinition {

	WebDriver driver;
	By firstName;
	By lastName;
	By email;
	By button;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver","D:/JavaDemo104/DemoBDDNew/mydriver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	}
	
	@After
	public void tearDown() throws InterruptedException {
		Thread.sleep(10000);
		driver.quit();
	}

	@Given("^Hotel booking Html page is given$")
	public void hotel_booking_Html_page_is_given(){
		// Write code here that turns the phrase above into concrete actions
		driver.get("D://JavaDemo104//DemoBDDNew//mypage//hotelbooking.html");
		firstName=By.xpath("//*[@id=\"txtFirstName\"]");
		lastName=By.xpath("//*[@id=\"txtLastName\"]");
		email=By.id("txtEmail");
		button=By.xpath("//*[@id=\"btnPayment\"]");
	}

	@When("^Clicking on submit button for first name validation$")
	public void clicking_on_submit_button_for_first_name_validation() {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(button).click();
	}

	@Then("^Alert is coming 'please fill the First Name'$")
	public void alert_is_coming_please_fill_the_First_Name() throws InterruptedException  {
		// Write code here that turns the phrase above into concrete actions
		String actualData=driver.switchTo().alert().getText() ;
		String expectedData="Please fill the First Name";
		assertEquals(expectedData, actualData);
		Thread.sleep(5000);
	}

	@When("^Clicking on submit button for last name validation$")
	public void clicking_on_submit_button_for_last_name_validation() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		driver.findElement(firstName).sendKeys("Diya");
		driver.findElement(button).click();
		Thread.sleep(5000);
	}

	@Then("^Alert is coming 'please fill the Last Name'$")
	public void alert_is_coming_please_fill_the_Last_Name()  {
		// Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		
	}

	@When("^Clicking on submit button for email validation$")
	public void clicking_on_submit_button_for_email_validation()  {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Alert is coming 'please fill the Email'$")
	public void alert_is_coming_please_fill_the_Email()  {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^Clicking on submit button for Mobile validation$")
	public void clicking_on_submit_button_for_Mobile_validation()  {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Alert is coming 'please fill the Mobile no'$")
	public void alert_is_coming_please_fill_the_Mobile_no() {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^Clicking on submit button for city validation$")
	public void clicking_on_submit_button_for_city_validation()  {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Alert is coming 'please select the city'$")
	public void alert_is_coming_please_select_the_city()  {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^Clicking on submit button for state validation$")
	public void clicking_on_submit_button_for_state_validation(){
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Alert is coming 'please select the state'$")
	public void alert_is_coming_please_select_the_state() {
		// Write code here that turns the phrase above into concrete actions
	}

}
