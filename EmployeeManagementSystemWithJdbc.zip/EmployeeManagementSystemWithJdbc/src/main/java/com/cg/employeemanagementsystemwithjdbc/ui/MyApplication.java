package com.cg.employeemanagementsystemwithjdbc.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.employeemanagementsystemwithjdbc.Exception.EmployeeException;
import com.cg.employeemanagementsystemwithjdbc.dto.Employee;
import com.cg.employeemanagementsystemwithjdbc.service.EmployeeService;
import com.cg.employeemanagementsystemwithjdbc.service.EmployeeServiceImpl;


public class MyApplication {
	static EmployeeService service;


	public static void main(String[] args) {
		service = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);

		int choice = 0;
	 do {
		 printDetails();
		 System.out.println("Enter the choice");
		 choice = sc.nextInt();
		 switch(choice) {
		 case 1:
			 System.out.println("Enter Employee Id");
			 int id = sc.nextInt();
			 System.out.println("Enter Employee Name");
			 String name = sc.next();
			 System.out.println("Enter the Salary");
			 double salary = sc.nextDouble();
				Employee emp= new Employee();

			 //Employee emp = new Employee();
			 
			 emp.setId(id);
			 emp.setName(name);
			 emp.setSalary(salary);
			 service.addEmployee(emp);
			 break;
		 case 2:
			 List<Employee>myList = service.showAll();
			 for(Employee empData : myList) {
				 System.out.println(empData);
				/* System.out.println("Id is "+empData.getId());
				 System.out.println("Name is "+empData.getName());
				 System.out.println("Salary is "+empData.getSalary());*/
			 }
			 break;
		 case 4:
			 System.out.println("Enter the Employee to search Name");
			 String sname = sc.next();
			 List<Employee>empSearch = service.findByName(sname);
			 for(Employee empAll:empSearch) {
				 System.out.println("ID is "+ empAll.getId());
			 }
			 break;
		 case 3:
			 System.out.println("Enter Employee Id");
			 int sid= sc.nextInt();
			 try {
			Employee empsearch= service.findById(sid);
			System.out.println(empsearch);
			if(empsearch != null) {
				
				System.out.println("Enter Salary");
				double salnew=sc.nextDouble();
				empsearch.setSalary(salnew);
				service.update(empsearch);
			}
			 }
			catch(EmployeeException e) {
				 System.out.println(e.getMessage());
			 }
			 break;
		
		 }
		 
	 }while(choice!=6);
	}
	 public static void printDetails() {
		 System.out.println("1.Add Employee");
		 System.out.println("2.Show All Employee");
		 System.out.println("3.Update Employee");
		 System.out.println("4.Search");
		 System.out.println("5.sort");
	 }
	}

