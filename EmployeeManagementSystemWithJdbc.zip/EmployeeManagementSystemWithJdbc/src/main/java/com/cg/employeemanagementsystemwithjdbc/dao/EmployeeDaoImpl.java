package com.cg.employeemanagementsystemwithjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.employeemanagementsystemwithjdbc.dto.Employee;
import com.cg.employeemanagementsystemwithjdbc.util.DbUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	Connection con = DbUtil.getConnection();

	PreparedStatement pstm;
		public Employee save(Employee emp) {
			
			try {
				pstm = con.prepareStatement("INSERT INTO employee VALUE( ?,?,?)");
				pstm.setInt(1, emp.getId());
				 pstm.setString(2, emp.getName());
				 pstm.setDouble(3,emp.getSalary());
				 pstm.executeUpdate();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			 finally {
				 try {
	        	 if(pstm !=null)
		        		pstm.close();
				 }catch (SQLException e) {
					 e.printStackTrace();
				 }
				 
	        	 
	        try {
	        	 if(con!=null) 
	        		 con.close();
	        	 
	        	 } catch(SQLException e) {
        			 e.printStackTrace();
        		 }
	        }
			 
	        		
			return emp;
			}
			
	        

		/*@Override
		public List<Employee> findByName(String name) {
			List<Employee> empSearch = new  ArrayList();
			for(Employee employee : empData) {
				if(employee.getName().equals(name)) {
					empSearch.add(employee);
				}}
			return empSearch;
		}

		@Override
		public Employee findById(int id) throws EmployeeException {
			for(Employee employee: empData) {
				if(employee.getId()==id) {
					return employee;
				}else 
				{ 
					throw new EmployeeException ("Id not found..");
				}
			}
			return null;
		}

		@Override
		public List<Employee> showAll() {
			return empData;
		}
		
		
		

	}
*/


		public List<Employee> findByName(String name) {
			return null;
		}
		public Employee findById(int id) {
			return null;
		}
		public List<Employee> showAll() {
			Connection con =DbUtil.getConnection();
			String query_show = "SELECT emp_id,emp_name,emp_salary FROM employee";
			
			List<Employee> myList = new ArrayList<Employee>();
			try {
			pstm=con.prepareStatement(query_show);
			ResultSet result = pstm.executeQuery();
			if(result!=null)
			while(result.next()) {
				Employee emp = new Employee();
				emp.setId(result.getInt("emp_id"));
				emp.setName(result.getString("emp_name"));
				emp.setSalary(result.getDouble("emp_salary"));
				myList.add(emp);
				}}
				
			catch(SQLException e){
				e.printStackTrace();}
			return myList;
			/*}catch (SQLException e) {
				e.printStackTrace();
				throw new EmployeeException("Show not working");
			}
			finally {
				try {
					if(pstm!=null) {
					pstm.close();
					}
					con.close();
					
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			return myList;
		}*/
		}
}