package com.cg.employeemanagementsystemwithjdbc.dao;

import java.util.List;

import com.cg.employeemanagementsystemwithjdbc.Exception.EmployeeException;
import com.cg.employeemanagementsystemwithjdbc.dto.Employee;


public interface EmployeeDao {
	public Employee save(Employee emp);
	public List<Employee> findByName(String name);
	public Employee findById(int id);
	public List<Employee> showAll();
}
