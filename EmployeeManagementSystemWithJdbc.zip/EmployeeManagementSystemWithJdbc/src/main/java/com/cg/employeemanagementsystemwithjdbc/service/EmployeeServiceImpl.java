package com.cg.employeemanagementsystemwithjdbc.service;

import java.util.List;

import com.cg.employeemanagementsystemwithjdbc.dao.EmployeeDao;
import com.cg.employeemanagementsystemwithjdbc.dao.EmployeeDaoImpl;
import com.cg.employeemanagementsystemwithjdbc.dto.Employee;
import com.cg.employeemanagementsystemwithjdbc.util.DbUtil;


	public class EmployeeServiceImpl implements EmployeeService{
		EmployeeDao dao;
		public EmployeeServiceImpl() {
			dao=new EmployeeDaoImpl();
			
		}
		
		public void addEmployee(Employee emp) {
			dao.save(emp);
			
		}
		public List<Employee> findByName(String name) {
			return dao.findByName(name);
		}
		public Employee findById(int id) {
			return dao.findById(id);
		}
		public List<Employee> showAll() {
			
			return dao.showAll();
		}
		public Employee update(Employee emp) {
			return null;
		}
		public void sort() {
			
		}
}
