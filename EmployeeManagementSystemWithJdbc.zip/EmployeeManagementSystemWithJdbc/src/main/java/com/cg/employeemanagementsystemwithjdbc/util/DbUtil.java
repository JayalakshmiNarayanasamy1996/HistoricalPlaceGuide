package com.cg.employeemanagementsystemwithjdbc.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.cg.employeemanagementsystemwithjdbc.Exception.EmployeeException;


public class DbUtil {
	 static Connection conn;
	 
	public static Connection getConnection() {
		Properties prop = new Properties();
		try {
		FileInputStream it = new FileInputStream("src/main/resources/jdbc.property");
		prop.load(it);
		if(prop!=null) {
		String driver =prop.getProperty("driver");
		String url = prop.getProperty("url");
		String uname = prop.getProperty("username");
		String upass= prop.getProperty("password");
		Class.forName(driver);
		conn=DriverManager.getConnection(url,uname,upass);
		
	}
}
	
	catch (Exception e) {
	e.printStackTrace();
	throw new EmployeeException("Connection not established");
}
	return conn;
}
}
