package com.cg.employeemanagementsystemwithjdbc.Exception;

public class EmployeeException extends RuntimeException {
	public EmployeeException() {
		super();
	}
	public EmployeeException(String msg) {
		super();
	}

}
