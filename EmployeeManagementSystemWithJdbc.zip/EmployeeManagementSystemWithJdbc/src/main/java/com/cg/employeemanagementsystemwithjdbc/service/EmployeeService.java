package com.cg.employeemanagementsystemwithjdbc.service;

import java.util.List;

import com.cg.employeemanagementsystemwithjdbc.dto.Employee;


public interface EmployeeService {
	public void addEmployee(Employee emp);
	public List<Employee> findByName(String name);
	public Employee findById(int id);

	public List<Employee> showAll();
	public Employee update(Employee emp);
	public void sort();

}
