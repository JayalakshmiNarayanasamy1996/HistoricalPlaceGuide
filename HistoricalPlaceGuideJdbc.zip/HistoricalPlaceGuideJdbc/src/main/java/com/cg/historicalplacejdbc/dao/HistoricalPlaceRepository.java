package com.cg.historicalplacejdbc.dao;

import java.util.List;

import com.cg.historicalplacejdbc.dto.Guide;
import com.cg.historicalplacejdbc.dto.HistoricalPlace;


public interface HistoricalPlaceRepository {
	public HistoricalPlace save(HistoricalPlace historicalPlace);

	public List<HistoricalPlace> findByHistoricalPlaceCity(String city);

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name);
	public Guide saveGuide(Guide guide);


	//public List<HistoricalPlace> historicalPlaces();
}
