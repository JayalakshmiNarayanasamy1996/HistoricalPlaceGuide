package com.cg.historicalplacejdbc.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.cg.historicalplacejdbc.exception.HistoricalplaceException;

public class DbUtil {
	 static Connection conn;
		public static Connection getConnection() {
			Properties prop = new Properties();
			try {
			FileInputStream it = new FileInputStream("src/main/resources/jdbc.properties");
			prop.load(it);
			if(prop!=null) {
			String driver =prop.getProperty("driver");
			String url = prop.getProperty("url");
			String uname = prop.getProperty("username");
			String upass= prop.getProperty("password");
			Class.forName(driver);
			conn=DriverManager.getConnection(url,uname,upass);
			
		}
	}
		catch (Exception e) {
		e.printStackTrace();
		throw new HistoricalplaceException("Connection not established");
	}
		return conn;
	}

}
