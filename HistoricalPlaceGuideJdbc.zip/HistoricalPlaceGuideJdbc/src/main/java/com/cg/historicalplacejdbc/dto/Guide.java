package com.cg.historicalplacejdbc.dto;

import java.math.BigInteger;

public class Guide {
	private String name;
	private BigInteger mobileNumber;
	private String country;
	private String state;
	private String city;
	private String area;

	public Guide() {
	}

	public Guide(String name, BigInteger mobileNumber, String country, String state, String city, String area) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.country = country;
		this.state = state;
		this.city = city;
		this.area = area;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	@Override
	public String toString() {
		return "Guide [name=" + name + ", mobileNumber=" + mobileNumber + ", country=" + country + ", state=" + state
				+ ", city=" + city + ", area=" + area + "]";
	}



}
