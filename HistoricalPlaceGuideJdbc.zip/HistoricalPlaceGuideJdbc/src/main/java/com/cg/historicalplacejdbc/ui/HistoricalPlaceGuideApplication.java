package com.cg.historicalplacejdbc.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.historicalplacejdbc.dto.ContactPerson;
import com.cg.historicalplacejdbc.dto.Guide;
import com.cg.historicalplacejdbc.dto.HistoricalPlace;
import com.cg.historicalplacejdbc.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplacejdbc.exception.HistoricalplaceException;
import com.cg.historicalplacejdbc.service.HistoricalPlaceService;
import com.cg.historicalplacejdbc.service.HistoricalPlaceServiceImpl;

public class HistoricalPlaceGuideApplication {

	static HistoricalPlaceService service;
	Guide guide = new Guide();

	public static void main(String[] args) {
		service = new HistoricalPlaceServiceImpl();
		Scanner sc = new Scanner(System.in);
		List<Guide> guideList = new ArrayList<Guide>();
		ContactPerson contactPerson = new ContactPerson();
		List<HistoricalPlace> historicalList = new ArrayList<HistoricalPlace>();

		int choice = 0;
		do {
			printDetails();
			System.out.println("Enter choice: ");
			choice = sc.nextInt();
			switch (choice) {
			case 1:// Add HistoricalPlace
				
				System.out.println("............................................ ");
				System.out.println("Enter HistoricalPlace Country: ");
				String country = sc.next();
				System.out.println("Enter HistoricalPlace State: ");
				String state = sc.next();
				System.out.println("Enter HistoricalPlace City: ");
				String city = sc.next();
				System.out.println("Enter HistoricalPlace Area : ");
				String area = sc.next();
				HistoricalPlace historicalPlace = new HistoricalPlace();
				historicalPlace.setCountry(country);
				historicalPlace.setState(state);
				historicalPlace.setCity(city);
				historicalPlace.setArea(area);
				historicalList.add(historicalPlace);
				
				System.out.println("............................................ ");
				System.out.println("Enter the ContactPerson  to assign the  details in historicalPlace....");
				ContactPerson conPerson = new ContactPerson();
				System.out.println("Enter ContactPerson Name: ");
				String name = sc.next();
				System.out.println("Enter ContactPerson MobileNumber: ");
				BigInteger mobileNumber = sc.nextBigInteger();
				conPerson.setName(name);
				conPerson.setMobileNumber(mobileNumber);
				service.assignContactPerson(conPerson);
				System.out.println("ContactPerson Name: " + conPerson.getName());
				System.out.println("ContactPerson MobileNumber: " + conPerson.getMobileNumber());

				

				System.out.println("............................................ ");
				System.out.println("Enter the Guide Details to Register !!!!!!!!!");
				Guide guides = new Guide();
				System.out.println("Enter Guide Name: ");
				String guideName = sc.next();
				System.out.println("Enter Guide MobileNumber: ");
				BigInteger guideMobileNumber = sc.nextBigInteger();
				System.out.println("Enter Guide Country: ");
				String guideCountry = sc.next();
				System.out.println("Enter Guide State: ");
				String guideState = sc.next();
				System.out.println("Enter Guide City: ");
				String guideCity = sc.next();
				System.out.println("Enter Guide Area : ");
				String guideArea = sc.next();
				guides.setName(guideName);
				guides.setMobileNumber(guideMobileNumber);
				guides.setCountry(guideCountry);
				guides.setState(guideState);
				guides.setCity(guideCity);
				guides.setArea(guideArea);
				System.out.println("GuideName:" + guides.getName());
				System.out.println("GuideMobileNumber:" + guides.getMobileNumber());
				System.out.println("GuideCountry: " + guides.getCountry());
				System.out.println("GuideState: " + guides.getState());
				System.out.println("GuideCity: " + guides.getCity());
				System.out.println("GuideArea: " + guides.getArea());
				guideList.add(guides);
				historicalPlace.setGuide(guideList);
				historicalPlace.setContactPerson(conPerson);
				service.addHistoricalPlace(historicalPlace);
				break;

			case 2: // Register Guide
				Guide guide = new Guide();
				System.out.println("Enter Guide Name: ");
				String gName = sc.next();
				System.out.println("Enter Guide MobileNumber: ");
				BigInteger gMobileNumber = sc.nextBigInteger();
				System.out.println("Enter Guide Country: ");
				String gCountry = sc.next();
				System.out.println("Enter Guide State: ");
				String gState = sc.next();
				System.out.println("Enter Guide City: ");
				String gCity = sc.next();
				System.out.println("Enter Guide Area : ");
				String gArea = sc.next();
				guide.setName(gName);
				guide.setMobileNumber(gMobileNumber);
				guide.setCountry(gCountry);
				guide.setState(gState);
				guide.setCity(gCity);
				guide.setArea(gArea);
				service.registerGuide(guide);
				System.out.println("GuideName:" + guide.getName());
				System.out.println("GuideMobileNumber:" + guide.getMobileNumber());
				System.out.println("GuideCountry: " + guide.getCountry());
				System.out.println("GuideState: " + guide.getState());
				System.out.println("GuideCity: " + guide.getCity());
				System.out.println("GuideArea: " + guide.getArea());
				guideList.add(guide);
				break;
			case 3:// Search Historical Place By City

				System.out.println("Enter HistoricalPlaceCity: ");
				city = sc.next();
				try {
					List<HistoricalPlace> historicalPlaceSearch = service.searchByHistoricalPlaceCity(city);
					for (HistoricalPlace historicalCity : historicalPlaceSearch) {
						System.out.println(".................................................");
						System.out.println("HistoricalPlace Country :" + historicalCity.getCountry());
						System.out.println("HistoricalPlace State :" + historicalCity.getState());
						System.out.println("HistoricalPlace Area :" + historicalCity.getArea());
						for(Guide g :historicalCity.getGuide()) {
							System.out.println("Guide Name : "+g.getName());
							System.out.println("Guide Country : "+g.getCountry());
							System.out.println("Guide State : "+g.getState());
							System.out.println("Guide City : "+g.getCity());
							System.out.println("Guide Area :"+g.getArea());
							
						}
						
					}
				} catch (HistoricalPlaceCityNotFound e) {
					System.out.println(" Historical Place City is Not Found ");
					e.printStackTrace();
				}

				break;
			case 4:// Search Historical Place Area By GuideName

				System.out.println("Enter GuideName");
				name = sc.next();
				try {
					List<HistoricalPlace> guideSearch = service.searchHistoricalPlaceAreaByGuideName(name);
					for (HistoricalPlace searchPlace : guideSearch) {
						System.out.println("HistoricalPlace State Is:"+searchPlace.getState());
						System.out.println("HistoricalPlace City Is:"+searchPlace.getCity());
						System.out.println("HistoricalPlaceArea Is:" + searchPlace.getArea());
						//System.out.println(searchPlace);
					}
				} catch (HistoricalplaceException e) {
					System.out.println("Guide Name is Not Found");
					e.printStackTrace();
				}
				break;
			}
		} while (choice != 5);
	}// main

	public static void printDetails() {
		System.out.println("1. Add HistoricalPlace ");
		System.out.println("2. RegisterGuide");
		System.out.println("3. SearchByHistoricalPlaceCity");
		System.out.println("4. SearchHistoricalPlaceAreaByGuideName");
		System.out.println("5. Exit");
	}// print
}// class
