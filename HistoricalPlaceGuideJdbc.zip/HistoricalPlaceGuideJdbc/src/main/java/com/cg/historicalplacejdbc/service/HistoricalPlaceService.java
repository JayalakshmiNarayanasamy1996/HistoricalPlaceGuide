package com.cg.historicalplacejdbc.service;

import java.util.List;

import com.cg.historicalplacejdbc.dto.ContactPerson;
import com.cg.historicalplacejdbc.dto.Guide;
import com.cg.historicalplacejdbc.dto.HistoricalPlace;


public interface HistoricalPlaceService {
	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace);

	//public List<HistoricalPlace> historicalPlaceDetails();

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city);

	public ContactPerson assignContactPerson(ContactPerson contactPerson);

	public Guide registerGuide(Guide guide);

	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name);


}
