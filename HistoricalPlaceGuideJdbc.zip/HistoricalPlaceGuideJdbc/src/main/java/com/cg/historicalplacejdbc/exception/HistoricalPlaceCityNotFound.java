package com.cg.historicalplacejdbc.exception;

public class HistoricalPlaceCityNotFound extends RuntimeException {
	public HistoricalPlaceCityNotFound() {
	super();
}
public HistoricalPlaceCityNotFound(String msg) {
	super();
}

}
