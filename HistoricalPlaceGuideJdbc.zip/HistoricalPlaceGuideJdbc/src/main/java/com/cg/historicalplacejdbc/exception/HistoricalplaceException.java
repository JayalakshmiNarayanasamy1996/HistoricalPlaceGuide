package com.cg.historicalplacejdbc.exception;

public class HistoricalplaceException extends RuntimeException{
	public HistoricalplaceException() {
		super();
	}
	public HistoricalplaceException(String msg) {
		super();
	}

}
