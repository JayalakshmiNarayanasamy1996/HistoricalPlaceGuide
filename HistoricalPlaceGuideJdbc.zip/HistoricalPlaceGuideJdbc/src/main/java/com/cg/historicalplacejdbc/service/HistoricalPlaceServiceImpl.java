package com.cg.historicalplacejdbc.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.historicalplacejdbc.dao.HistoricalPlaceRepositoryImpl;
import com.cg.historicalplacejdbc.dao.HistoricalPlaceRepository;
import com.cg.historicalplacejdbc.dto.ContactPerson;
import com.cg.historicalplacejdbc.dto.Guide;
import com.cg.historicalplacejdbc.dto.HistoricalPlace;
import com.cg.historicalplacejdbc.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplacejdbc.exception.HistoricalplaceException;

public class HistoricalPlaceServiceImpl implements HistoricalPlaceService {
	HistoricalPlaceRepository repo;

	public HistoricalPlaceServiceImpl() {
		repo = new HistoricalPlaceRepositoryImpl();
	}

	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) {
		return repo.save(historicalPlace);
	}

	public ContactPerson assignContactPerson(ContactPerson contactPerson) {
		return contactPerson;
	}

	public Guide registerGuide(Guide guides) {
		return repo.saveGuide(guides);
	}

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) {
		List<HistoricalPlace> place = repo.findByHistoricalPlaceCity(city);
		if (place.isEmpty())
			throw new HistoricalPlaceCityNotFound("Historical Place City is  Not Found");
		return place;
	}

	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name) {
		List<HistoricalPlace> area = repo.findHistoricalPlaceAreaByGuideName(name);
		if (area.isEmpty())
			throw new HistoricalplaceException("Guide Name is Not Found Try Again with Correct GuideName");
		return area;
	}

}
