package com.cg.historicalplacejdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.historicalplacejdbc.dto.ContactPerson;
import com.cg.historicalplacejdbc.dto.Guide;
import com.cg.historicalplacejdbc.dto.HistoricalPlace;
import com.cg.historicalplacejdbc.util.DbUtil;

public class HistoricalPlaceRepositoryImpl implements HistoricalPlaceRepository {
	Connection con = null;
	PreparedStatement pstm = null;
	ResultSet result = null;
	String query = null;

	public HistoricalPlace save(HistoricalPlace historicalPlace) {
		con = DbUtil.getConnection();
		try {
			
			ContactPerson contactPerson = new ContactPerson();
			query = "insert into historicalplace(h_country,h_state,h_city,h_area) values(?,?,?,?)";
			pstm = con.prepareStatement(query);
			pstm.setString(1, historicalPlace.getCountry());
			pstm.setString(2, historicalPlace.getState());
			pstm.setString(3, historicalPlace.getCity());
			pstm.setString(4, historicalPlace.getArea());
			//pstm.setString(5, contactPerson.getMobileNumber().toString());
			int res = pstm.executeUpdate();
			int h_id = 0;
			if (res > 0) {
				query = "select max(h_id) from historicalplace";
				pstm = con.prepareStatement(query);
				result = pstm.executeQuery();
				if (result.next()) {
					h_id = result.getInt(1);
				}}
			query = "insert into contactperson(c_name,c_mobileno,h_id) values(?,?,?)";
			pstm= con.prepareStatement(query);
			pstm.setString(1, historicalPlace.getContactPerson().getName());
			pstm.setString(2, historicalPlace.getContactPerson().getMobileNumber().toString());
			pstm.setInt(3, h_id);
			pstm.executeUpdate();
			
			System.out.println(historicalPlace.getGuide());
			for(Guide guide : historicalPlace.getGuide()) {
			query = "insert into guide(g_name,g_mobileno,g_country,g_state,g_city,g_area,h_id) values(?,?,?,?,?,?,?)";
			pstm = con.prepareStatement(query);
			pstm.setString(1, guide.getName());
			pstm.setString(2, guide.getMobileNumber().toString());
			pstm.setString(3, guide.getCountry());
			pstm.setString(4, guide.getState());
			pstm.setString(5, guide.getCity());
			pstm.setString(6, guide.getArea());
			pstm.setInt(7, h_id);
			pstm.executeUpdate();
			if(res>0)
				return historicalPlace;}}
		 catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null)
					pstm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (con != null)
					con.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return historicalPlace;
	}

	public List<HistoricalPlace> findByHistoricalPlaceCity(String city) {
		con = DbUtil.getConnection();
		List<HistoricalPlace> findCity = new ArrayList<HistoricalPlace>();
		try {
			pstm = con.prepareStatement("select h.h_country,h.h_state, h.h_city,h.h_area h_id ,g.g_name,g.g_country,g.g_state,g.g_city,g.g_area from historicalplace h join guide g on g.h_id = h.h_id where h.h_city=?");
			pstm.setString(1, city);
			result =pstm.executeQuery();
			if(result!=null) {
				while(result.next()) {
					HistoricalPlace historicalPlace = new HistoricalPlace();
					historicalPlace.setCountry(result.getString(1));
					historicalPlace.setState(result.getString(2));
					historicalPlace.setCity(result.getString(3));
					historicalPlace.setArea(result.getString(4));

					Guide g = new Guide();
					List<Guide> guideList = new ArrayList<Guide>();
					g.setName(result.getString(5));
					g.setCountry(result.getString(1));
					g.setState(result.getString(2));
					g.setCity(result.getString(3));
					g.setArea(result.getString(4));
					guideList.add(g);
					historicalPlace.setGuide(guideList);;
					findCity.add(historicalPlace);
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return findCity;
	}

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name) {
		con=DbUtil.getConnection();
		List<HistoricalPlace> area = new ArrayList<HistoricalPlace>();
		try {
			pstm=con.prepareStatement("select h.h_country, h.h_state, h.h_area, h.h_city from historicalplace h join guide g on g.h_id=h.h_id where g.g_name=? ");
			pstm.setString(1, name);
			ResultSet rs = pstm.executeQuery();
			while(rs.next()) {
				HistoricalPlace h=new HistoricalPlace();
				h.setCountry(rs.getString(1));
				h.setState(rs.getString(2));
				h.setArea(rs.getString(3));
				h.setCity(rs.getString(4));
				area.add(h);
		}
		}
	catch(SQLException e) {
		e.printStackTrace();
	}
		return area;
	}

	public Guide saveGuide(Guide guide) {
		Connection con = DbUtil.getConnection();
		int h_id=0;
		try {
			query ="select h_id from historicalplace where h_city=?";
			pstm=con.prepareStatement(query);
			pstm.setString(1, guide.getCity());
			
			result = pstm.executeQuery();
			while(result.next()) {
				h_id=result.getInt(1);
			}
		query = "insert into guide(g_name,g_mobileno,g_country,g_state,g_city,g_area,h_id) values(?,?,?,?,?,?,?)";
		pstm = con.prepareStatement(query);
		pstm.setString(1, guide.getName());
		pstm.setString(2, guide.getMobileNumber().toString());
		pstm.setString(3, guide.getCountry());
		pstm.setString(4, guide.getState());
		pstm.setString(5, guide.getCity());
		pstm.setString(6, guide.getArea());
		pstm.setInt(7, h_id);
		int res =0;
		res=pstm.executeUpdate();
		if(res>0)
			return guide;
		}
	 catch (SQLException e) {
		e.printStackTrace();
	} 
	 finally {
		try {
			if (pstm != null)
				pstm.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if (con != null)
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	return guide;
	}


}
