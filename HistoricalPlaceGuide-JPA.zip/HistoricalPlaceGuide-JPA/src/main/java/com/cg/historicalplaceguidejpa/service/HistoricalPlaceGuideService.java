package com.cg.historicalplaceguidejpa.service;

import java.util.List;

import com.cg.historicalplaceguidejpa.dto.ContactPerson;
import com.cg.historicalplaceguidejpa.dto.Guide;
import com.cg.historicalplaceguidejpa.dto.HistoricalPlace;
import com.cg.historicalplaceguidejpa.exception.GuideNameNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceException;

public interface HistoricalPlaceGuideService {
	
	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) throws HistoricalPlaceException;

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound;

	public ContactPerson assignContactPerson(ContactPerson contactPerson);

	public Guide registerGuide(Guide guide) throws HistoricalPlaceException;

	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name) throws GuideNameNotFound;

}
