package com.cg.historicalplaceguidejpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.historicalplaceguidejpa.dto.Guide;
import com.cg.historicalplaceguidejpa.dto.HistoricalPlace;
import com.cg.historicalplaceguidejpa.exception.GuideNameNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceException;
import com.cg.historicalplaceguidejpa.util.DbUtil;


public class HistoricalPlaceGuideDaoImpl implements HistoricalPlaceGuideDao {
	
	public HistoricalPlaceGuideDaoImpl() {
	}
	/*
	 * Written by N.Jayalakshmi on 04-05-2019
	 * last modified on 04-05-2019
	 * Save() method saves the historicalplace, guide, contactperson details..
	 */

	public HistoricalPlace save(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
		EntityManager entityManager = DbUtil.getConnection();
		try {
			entityManager.persist(historicalPlace);
			entityManager.getTransaction().commit();
			return historicalPlace;
		}catch (Exception e) {
			throw new HistoricalPlaceException("HistoricalPlace Details is Already Added");
		}finally {
			entityManager.close();
		}
	}
	/* Written by N.Jayalakshmi on 04-05-2019
	 * last modified on 04-05-2019
	 * This FindByHistoricalplacecity() method returns the Historicalplace details and guide Details
	 */
	public List<HistoricalPlace> findByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound {
		EntityManager entityManager = DbUtil.getConnection();
		try {
			Query query = entityManager.createQuery("from HistoricalPlace where city= :city");
			query.setParameter("city", city);
			return query.getResultList();
		}catch (HistoricalPlaceCityNotFound e) {	
			throw new HistoricalPlaceCityNotFound("Historical place city is Not Found ");
		}finally {
			entityManager.close();
		}
	}
	/*
	 * Written by N.Jayalakshmi on 04-05-2019
	 * last modified on 04-05-2019
	 * This findHistoricalPlaceAreaByGuideName() method returns the Guide(he/she) present in which historicalPlace 
	 * and gives the Historicalplace Details 
	 */

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name) throws GuideNameNotFound {
		EntityManager entityManager = DbUtil.getConnection();
		try {
			Query queryOne = entityManager
					.createQuery("select h from  HistoricalPlace h, in(h.guide) g  where  g.name= :name");
			queryOne.setParameter("name", name);
			List<HistoricalPlace> historicalPlaceArea = queryOne.getResultList();
			return historicalPlaceArea;
		}catch (GuideNameNotFound e) {
			throw new GuideNameNotFound("Guide Name is Not Found");
		}finally {
			entityManager.close();
		}
	}
		/*
		 * Written by N.Jayalakshmi on 04-05-2019
		 * last modified on 04-05-2019
		 * SaveGuide() method saves the Guides to the Particular historicalplace
		 * */
	public Guide saveGuide(Guide guide) throws HistoricalPlaceException {
		EntityManager entityManager = DbUtil.getConnection();
		try {
		TypedQuery<HistoricalPlace> query= entityManager.createQuery("select h from HistoricalPlace h where h.city= :city",HistoricalPlace.class);
		query.setParameter("city",guide.getCity());
		HistoricalPlace his =query.getSingleResult();
		List<Guide> gList = his.getGuide();
		gList.add(guide);
		his.setGuide(gList);
		entityManager.persist(his);
		entityManager.getTransaction().commit();
		return guide;
		}catch (Exception e) {
		 throw new HistoricalPlaceException("There is no Historical place City found for this Guide");
		}finally {
			entityManager.close();
		}
	}
	} 

