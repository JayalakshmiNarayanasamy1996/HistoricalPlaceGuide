package com.cg.historicalplaceguidejpa.exception;

public class HistoricalPlaceCityNotFound extends RuntimeException {
	public HistoricalPlaceCityNotFound() {
		super();
	}

	public HistoricalPlaceCityNotFound(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public HistoricalPlaceCityNotFound(String message, Throwable cause) {
		super(message, cause);
	}

	public HistoricalPlaceCityNotFound(String message) {
		super(message);
	}

	public HistoricalPlaceCityNotFound(Throwable cause) {
		super(cause);
	}
	
	
	
}
