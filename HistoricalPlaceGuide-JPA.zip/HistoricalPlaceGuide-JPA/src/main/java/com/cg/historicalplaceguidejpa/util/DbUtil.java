package com.cg.historicalplaceguidejpa.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DbUtil {
	static EntityManager entityManager= null;
	public static  EntityManager getConnection() {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("historicalplaceguide");
	entityManager=entityManagerFactory.createEntityManager();
	entityManager.getTransaction().begin();
	return entityManager;
	
	}

}
