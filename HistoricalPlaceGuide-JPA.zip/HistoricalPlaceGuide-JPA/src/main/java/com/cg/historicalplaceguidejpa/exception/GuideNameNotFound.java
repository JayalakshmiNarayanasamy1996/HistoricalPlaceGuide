package com.cg.historicalplaceguidejpa.exception;

public class GuideNameNotFound extends RuntimeException{

	public GuideNameNotFound() {
	super();
}

	public GuideNameNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public GuideNameNotFound(String message, Throwable cause) {
		super(message, cause);
	}

	public GuideNameNotFound(String message) {
		super(message);
	}

	public GuideNameNotFound(Throwable cause) {
		super(cause);
	}


}
