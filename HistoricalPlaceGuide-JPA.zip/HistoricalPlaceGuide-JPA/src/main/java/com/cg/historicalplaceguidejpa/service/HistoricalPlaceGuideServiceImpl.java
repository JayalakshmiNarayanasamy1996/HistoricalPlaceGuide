package com.cg.historicalplaceguidejpa.service;

import java.util.List;
import java.util.Random;

import com.cg.historicalplaceguidejpa.dao.HistoricalPlaceGuideDao;
import com.cg.historicalplaceguidejpa.dao.HistoricalPlaceGuideDaoImpl;
import com.cg.historicalplaceguidejpa.dto.ContactPerson;
import com.cg.historicalplaceguidejpa.dto.Guide;
import com.cg.historicalplaceguidejpa.dto.HistoricalPlace;
import com.cg.historicalplaceguidejpa.exception.GuideNameNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceException;

public class HistoricalPlaceGuideServiceImpl implements HistoricalPlaceGuideService {
	public static int h_id=0;
	HistoricalPlaceGuideDao dao;
	public HistoricalPlaceGuideServiceImpl() {
		dao = new HistoricalPlaceGuideDaoImpl();
		
	}

	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
		h_id=new Random().nextInt(1000);
		h_id++;
		historicalPlace.setH_id(h_id);
		return dao.save(historicalPlace);
	}

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound{
		List<HistoricalPlace> place = dao.findByHistoricalPlaceCity(city);
		if (place.isEmpty())
			throw new HistoricalPlaceCityNotFound("Historical Place City is  Not Found");
		return place;
	}

	public ContactPerson assignContactPerson(ContactPerson contactPerson) {
		return contactPerson;
	}

	public Guide registerGuide(Guide guide) throws HistoricalPlaceException {
		Guide g = dao.saveGuide(guide);
		if(g== null)
			throw new HistoricalPlaceException(" There is no Historical place City found for this Guide");
		return g;
	}
	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name) throws GuideNameNotFound{
		List<HistoricalPlace> area = dao.findHistoricalPlaceAreaByGuideName(name);
		if (area.isEmpty())
			throw new GuideNameNotFound("Guide Name is  Not Found");
		return area;
	}

}
