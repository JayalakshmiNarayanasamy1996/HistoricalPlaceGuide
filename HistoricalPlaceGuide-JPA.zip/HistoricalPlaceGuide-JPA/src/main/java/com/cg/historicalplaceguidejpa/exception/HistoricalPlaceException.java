package com.cg.historicalplaceguidejpa.exception;

public class HistoricalPlaceException extends RuntimeException{
	public HistoricalPlaceException() {
		super();
	}

	public HistoricalPlaceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public HistoricalPlaceException(String message, Throwable cause) {
		super(message, cause);
	}

	public HistoricalPlaceException(String message) {
		super(message);
	}

	public HistoricalPlaceException(Throwable cause) {
		super(cause);
	}
	

}
