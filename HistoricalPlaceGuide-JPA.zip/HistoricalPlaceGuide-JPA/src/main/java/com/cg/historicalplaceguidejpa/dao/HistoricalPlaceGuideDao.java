package com.cg.historicalplaceguidejpa.dao;

import java.util.List;

import com.cg.historicalplaceguidejpa.dto.Guide;
import com.cg.historicalplaceguidejpa.dto.HistoricalPlace;
import com.cg.historicalplaceguidejpa.exception.GuideNameNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidejpa.exception.HistoricalPlaceException;

public interface HistoricalPlaceGuideDao {
	public HistoricalPlace save(HistoricalPlace historicalPlace) throws HistoricalPlaceException;

	public List<HistoricalPlace> findByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound;

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name) throws GuideNameNotFound;

	public Guide saveGuide(Guide guide) throws HistoricalPlaceException;

}
