package com.cg.historicalplaceguidespringmvc.dto;


import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * @author Jayalakshmi Narayansamy
 * write on 20-05-2019
 * last Modified 21-05-2019
 * class ContactPerson declare as entity
 *@returns Contact Person
 * @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
 */
@Entity
@Table(name = "contactperson")
public class ContactPerson {
	
	@Column(name ="c_name")
	private String name;
	@Id
	@Column(unique=true ,name="c_mobileno" , nullable = false)
	private BigInteger mobileNumber;
	
	public ContactPerson() {
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public ContactPerson(String name, BigInteger mobileNumber) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "ContactPerson [name=" + name + ", mobileNumber=" + mobileNumber + "]";
	}

}
