package com.cg.historicalplaceguidespringmvc.dao;

import java.util.List;

import com.cg.historicalplaceguidespringmvc.dto.Guide;
import com.cg.historicalplaceguidespringmvc.dto.HistoricalPlace;
import com.cg.historicalplaceguidespringmvc.exception.GuideNameNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceException;

/**
 * @Author Jayalakshmi
 * write on 20-05-2019
 * lastModified 20-05-2019
 * Interface class used to declare the methods
 * @returns historical details
 * @exception com.cg.historicalplaceguidespringmvc.exception
 */
public interface HistoricalPlaceRepository {

	public HistoricalPlace save(HistoricalPlace historicalPlace)throws HistoricalPlaceException;

	public List<HistoricalPlace> findByHistoricalPlaceCity(String city)throws HistoricalPlaceCityNotFound;

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name)throws GuideNameNotFound;
	public Guide saveGuide(Guide guide)throws HistoricalPlaceException;


}
