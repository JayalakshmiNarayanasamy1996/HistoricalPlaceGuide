package com.cg.historicalplaceguidespringmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.historicalplaceguidespringmvc.controller.HistoricalPlaceController;
import com.cg.historicalplaceguidespringmvc.dto.Guide;
import com.cg.historicalplaceguidespringmvc.dto.HistoricalPlace;
import com.cg.historicalplaceguidespringmvc.exception.GuideNameNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceException;
import com.cg.historicalplaceguidespringmvc.query.HistoricalPlaceGuideQuery;


/**
 * Written by N.Jayalakshmi on 04-05-2019
 * last modified on 21-05-2019
 * class HistoricalPlaceRepositoryImpl add the data to the database 
 */
@Repository
public class HistoricalPlaceRepositoryImpl implements HistoricalPlaceRepository {
	@PersistenceContext
	EntityManager entityManager;
/**
 * Written by N.Jayalakshmi on 04-05-2019
 * last modified on 21-05-2019
 * save method save the historical Place details to database
 * @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
 * @returns historical Place
 */
	@Override
	public HistoricalPlace save(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
		try {
			entityManager.persist(historicalPlace);
			entityManager.flush();
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return historicalPlace;
	}

	

	/**
	 * Written by N.Jayalakshmi on 04-05-2019
	 * last modified on 21-05-2019
	 * This FindByHistoricalplacecity() method returns the HistoricalPlace details and guide Details
	 * @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceCityNotFound
	 * @returns historical place details and guide Details
	 */
	public List<HistoricalPlace> findByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound {
		
		if(HistoricalPlaceController.logger.isDebugEnabled()){
			HistoricalPlaceController.logger.debug("HistoricalPlaceRepository findByHistoricalPlaceCity(HistoricalPlace) is executed!");
		}
	
		try {
			Query query = entityManager.createQuery(HistoricalPlaceGuideQuery.Query);
			query.setParameter("city", city);
			return query.getResultList();
		}catch (HistoricalPlaceCityNotFound e) {	
			throw new HistoricalPlaceCityNotFound("Historical place city is Not Found ");
		}finally {
			entityManager.close();
		}
	}
	/**
	 * Written by N.Jayalakshmi on 04-05-2019
	 * last modified on 21-05-2019
	 * This findHistoricalPlaceAreaByGuideName() method returns the Guide(he/she) present in which historicalPlace 
	 * and gives the HistoricalPlace Details 
	 * @exception com.cg.historicalplaceguidespringmvc.GuideNameNotFound
	 * @returns historicalPlaceArea and Historical Place details
	 */

	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name) throws GuideNameNotFound {
		
		if(HistoricalPlaceController.logger.isDebugEnabled()){
			HistoricalPlaceController.logger.debug("HistoricalPlaceRepository findHistoricalPlaceAreaByGuideName(HistoricalPlace) is executed!");
		}
		try {
			Query queryOne = entityManager
					.createQuery(HistoricalPlaceGuideQuery.QueryOne);
			queryOne.setParameter("name", name);
			List<HistoricalPlace> historicalPlaceArea = queryOne.getResultList();
			return historicalPlaceArea;
		}catch (GuideNameNotFound e) {
			throw new GuideNameNotFound("Guide Name is Not Found");
		}finally {
			entityManager.close();
		}
	}
		/**
		 * Written by N.Jayalakshmi on 04-05-2019
		 * last modified on 21-05-2019
		 * SaveGuide() method saves the Guides to the Particular historicalPlace
		 * @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
		 * @returns guides
		 * */
	public Guide saveGuide(Guide guide) throws HistoricalPlaceException {
		
		if(HistoricalPlaceController.logger.isDebugEnabled()){
			HistoricalPlaceController.logger.debug("HistoricalPlaceRepository saveGuide(Guide) is executed!");
		}
		try {
		TypedQuery<HistoricalPlace> query= entityManager.createQuery(HistoricalPlaceGuideQuery.QueryTwo,HistoricalPlace.class);
		query.setParameter("city",guide.getCity());
		HistoricalPlace historicalList =query.getSingleResult();
		guide.setHistoricalPlace(historicalList);
		
		List<Guide> guideList = historicalList.getGuide();
		guideList.add(guide);
		historicalList.setGuide(guideList);
		entityManager.persist(guide);
		entityManager.flush();
		return guide;
		//==================================//
		
		}catch (Exception e) {
		 throw new HistoricalPlaceException("There is no Historical place City found for this Guide");
		}finally {
			entityManager.close();
		}
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*public HistoricalPlace save(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
	
	if(HistoricalPlaceController.logger.isDebugEnabled()){
		HistoricalPlaceController.logger.debug("HistoricalPlaceRepository save(HistoricalPlace) is executed!");
	}
	
	HistoricalPlace histo =getHistoricalPlace(historicalPlace.getCity());
	//HistoricalPlace histo=getHistoricalPlace(historicalPlace);
	System.out.println("city:......"+histo);
	if(histo==null) {
	entityManager.persist(historicalPlace);
	entityManager.flush();
	}else {
		System.out.println("dao...."+historicalPlace);
		Guide guides = new Guide();
		guides.setCity(historicalPlace.getGuide().get(0).getCity());
		guides.setHistoricalPlace(histo);
		entityManager.persist(guides);
		entityManager.flush();
	}
	return historicalPlace;
	
}*/
/*public HistoricalPlace getHistoricalPlace(String city) {
HistoricalPlace cities=null;
try {
Query query =entityManager.createQuery("FROM HistoricalPlace  WHERE city=:city");

query.setParameter("city", city);
cities= (HistoricalPlace)query.getSingleResult();
}catch(NoResultException ex) {
	System.out.println("City Not Found");
}
return cities;
}
*/
	
	/*public HistoricalPlace getHistoricalPlace(int id) {
		HistoricalPlace h_id=null;
		try {
		Query query =entityManager.createQuery("FROM HistoricalPlace  WHERE h_id=:h_id");

		query.setParameter("h_id", h_id);
		h_id= (HistoricalPlace)query.getSingleResult();
		}catch(NoResultException ex) {
			System.out.println("City Not Found");
		}
		return h_id;
	}*/
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*List<HistoricalPlace> historicalPlaceCity;
	List<HistoricalPlace> historicalPlaceArea;

	public HistoricalPlaceRepositoryImpl() {
	}
*//**@Author JayalakshmiNarayanasamy
 *  lastModified 16-05-2019
 * save method used to store the Guide,ContactPerson and Historical place Details
 * (non-Javadoc)
 * @see com.cg.historicalplaceguidespringmvc.dao.HistoricalPlaceRepository#save(com.cg.historicalplaceguidespringmvc.dto.HistoricalPlace)
 *//*
	public HistoricalPlace save(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
		DBUtil.historicalPlaces.add(historicalPlace);
		return historicalPlace;
	}
*//**
 * @author JayalakshmiNarayanasamy
 * @param
 * @Exception 
 *  lastModified 16-05-2019
 * findByHistoricalPlaceCity find the city and returns the historical place and registered guide details 
 * (non-Javadoc)
 * @see com.cg.historicalplaceguidespringmvc.dao.HistoricalPlaceRepository#findByHistoricalPlaceCity(java.lang.String)
 *//*
	public List<HistoricalPlace> findByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound {
		historicalPlaceCity = new ArrayList<HistoricalPlace>();
		for (HistoricalPlace histoCity : DBUtil.historicalPlaces) {
			if (histoCity.getCity().equals(city))
				historicalPlaceCity.add(histoCity);
		}
		return historicalPlaceCity;
	}
*//**@Author JayalakshmiNarayanasamy
 *  lastModified 16-05-2019
 * findHistoricalPlaceAreaByGuideName  finds the guide name and return the historical place details 
 * (non-Javadoc)
 * @see com.cg.historicalplaceguidespringmvc.dao.HistoricalPlaceRepository#findHistoricalPlaceAreaByGuideName(java.lang.String)
 *//*
	public List<HistoricalPlace> findHistoricalPlaceAreaByGuideName(String name) throws HistoricalPlaceException {
		historicalPlaceArea = new ArrayList<HistoricalPlace>();
		for (HistoricalPlace historicalPlace : DBUtil.historicalPlaces) {
			for (Guide guide : historicalPlace.getGuide()) {
				if (guide.getName().equals(name)) {
					historicalPlaceArea.add(historicalPlace);
				}
			}
		}
		return historicalPlaceArea;
	}
	@Override
	public Guide saveGuide(Guide guide) {
		List<HistoricalPlace> historicalPlaces = new ArrayList<HistoricalPlace>();
		for(HistoricalPlace area :historicalPlaces)
			if(area.getArea().equals(guide.getArea())) {
				area.getGuide().add(guide);
				return guide;

	}
		return null;
	}
	
}
*/