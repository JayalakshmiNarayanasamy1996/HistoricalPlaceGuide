package com.cg.historicalplaceguidespringmvc.query;


/**
 *@author Jayalakshmi Narayansamy
 * write on 20-05-2019
 *last Modified 21-05-2019
 *@interface HistoricalPlaceGuideQuery performs with database
 **/

public interface HistoricalPlaceGuideQuery {
	String Query = "from HistoricalPlace where city= :city";
	String QueryOne = "select h from  HistoricalPlace h, in(h.guide) g  where  g.name= :name";
	String QueryTwo = "select h from HistoricalPlace h where h.city= :city";


}
