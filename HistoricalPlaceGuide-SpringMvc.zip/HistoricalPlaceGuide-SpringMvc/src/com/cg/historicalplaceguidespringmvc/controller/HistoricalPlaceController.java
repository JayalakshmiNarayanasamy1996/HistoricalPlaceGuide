package com.cg.historicalplaceguidespringmvc.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.historicalplaceguidespringmvc.dto.ContactPerson;
import com.cg.historicalplaceguidespringmvc.dto.Guide;
import com.cg.historicalplaceguidespringmvc.dto.HistoricalPlace;
import com.cg.historicalplaceguidespringmvc.exception.GuideNameNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceException;
import com.cg.historicalplaceguidespringmvc.service.HistoricalPlaceService;

@Controller
public class HistoricalPlaceController {
	
	
	public static final Logger logger = Logger.getLogger(HistoricalPlaceController.class);
	
	
	/**
	 * @Author Jayalakshmi Narayanasamy
	 * write on 20-05-2019
	 * Last Modified 22-05-2019
	 * class for controller purpose which takes input from user and interact with service
	 * and takes data from service and give to output
	 * @Exception com.cg.historicalplaceguidespringmvc.exception
	 * @return historicalPlace 
	 */
	
	@Autowired
	HistoricalPlaceService historicalPlaceService;
	
	@GetMapping("historicaldetails") 
	public String  loginPage() {
		return "historicaldetails";
	}
	@GetMapping("addHistoricalPlace") 
	public ModelAndView getAddHistoricalPlace(@ModelAttribute("his") HistoricalPlace historicalplace){ 
		return new ModelAndView("addhistoricalplace");
	}
	
	@PostMapping("historicalplace")
	public ModelAndView addedhistoricalPlace(@ModelAttribute("his") HistoricalPlace historicalPlace) {
		HistoricalPlace historical;
		try {
			historical=historicalPlaceService.addHistoricalPlace(historicalPlace);
			
		}catch (HistoricalPlaceException e) {
		return new ModelAndView("error");
			//System.out.println(e.getMessage());
		}
		return new ModelAndView("success","key",historical);
	}
	//-----------------------------****************************----------------------------------//
	/** @author jayalakshmi Narayanasamy
	 * write on 21-05-2019
	 * Last Modified 22-05-2019
	 * @param guide
	 * @return guide
	 * @exception com.cg.historicalplaceguidespringmvc.exception
	 */
	@GetMapping("registerGuide")
	public ModelAndView registerGuide(@ModelAttribute("his") Guide guide) {
		return new ModelAndView("registerguidelist");
		
	}
	
	@PostMapping("addedguide") 
	public ModelAndView addGuidelist(@ModelAttribute("his")Guide guide) {	
	Guide guideList;
		try {
			guideList =historicalPlaceService.registerGuide(guide);
		}catch (HistoricalPlaceException e) {
			System.err.println(e.getMessage());
			return new ModelAndView("registerexception");
    
		}
	     return new ModelAndView("error");
	
	}
	
	
	//---------------------****************************----------------------------//
	
	/**@Author  Jayalakshmi Narayanasamy
	 * write on 21-05-2019
	 * Last Modified 22-05-2019
	 * @param historicalPlace
	 * @return historicalPlace
	 * @exception com.cg.historicalplaceguidespringmvc.exception
	 */
	
	@GetMapping("search")
	public ModelAndView SearchHistoricalPlaceCity(@ModelAttribute("his") HistoricalPlace historicalPlace) {
		return new ModelAndView("searchcity");
	}
	@ExceptionHandler(HistoricalPlaceCityNotFound.class)
	@PostMapping("searchhistoricalCity")
	 public ModelAndView searchHistoricalCity(ModelAndView model,@ModelAttribute ("his") HistoricalPlace historicalPlace) {
		List<HistoricalPlace> historical;
		try {
		 historical=historicalPlaceService.searchByHistoricalPlaceCity(historicalPlace.getCity());
		model.addObject("showCity",historical );
		model.setViewName("searchcitypage");
		
		}catch (HistoricalPlaceCityNotFound e) {
			System.out.println(e.getMessage());
			return new ModelAndView("citynotfounderror");
		}
		return model;
	 }
//---------------******************************---------------------------------//
	
	/**@author Jayalakshmi Narayanasamy
	 * write on 21-05-2019
	 * Last Modified 22-05-2019
	 * @param guide
	 * @exception com.cg.historicalplaceguidespringmvc.exception
	 * @return historicalPlace
	 */

	 @GetMapping("guidesearch")
	public String searchHistoricalPlaceByGuideName() {
		 return "searchguide";
	}
	 @ExceptionHandler(GuideNameNotFound.class)
	@PostMapping("searchGuideName")
	public ModelAndView getsearchHistoricalPlaceByGuideName(ModelAndView model,@RequestParam("name") String name) {
		try {
		return new ModelAndView("searchguidepage" ,"showGuide",historicalPlaceService.searchHistoricalPlaceAreaByGuideName(name));
	}catch (GuideNameNotFound e) {
		System.out.println(e.getMessage());
		return new ModelAndView("guidenotfound");
	}
	}
	
	
}































/*	
@GetMapping("guidesearch")
	public ModelAndView searchHistoricalPlaceByGuideName(@RequestParam("name") String name) {
		return new ModelAndView("searchguide");
		
	}*/

/*-------------@PostMapping("historicalplace") 
public ModelAndView addHistoricalPlace(@ModelAttribute("his") HistoricalPlace  historicalplace) {
	//this.historical=historicalplace;
HistoricalPlace historicalPlace = historicalPlaceService.addHistoricalPlace(historicalplace);
return new ModelAndView("success","key",historicalPlace);
	//return new ModelAndView("addguide");
}*/
 // --------------Register Guide------------------------//
/*@PostMapping("historicalplace") 
public ModelAndView addHistoricalPlacetoguide(@ModelAttribute("his") Guide guide) {
	this.guides=guide;
	return new ModelAndView("addguide");
}

@PostMapping("addGuide") 
public ModelAndView addGuide(@RequestParam("h_id")int h_id,@RequestParam("name")String name,@RequestParam("mobileNumber")BigInteger mobileNumber,@RequestParam("country")String country,
		@RequestParam("state")String state ,@RequestParam("city")String city,@RequestParam("area")String area,@ModelAttribute("his") HistoricalPlace historicalPlace) {
	Guide guide =new Guide();
	guide.setCity(city);
	List<Guide> guideList = new ArrayList<>();
	HistoricalPlace historicalPlaces = new HistoricalPlace();
	if(historicalPlaces.getCity().equals(city)) {
	historicalPlaces.setH_id(h_id);
	historicalPlaces.setCountry(country);
	historicalPlaces.setState(state);
	historicalPlaces.setCity(city);
	historicalPlaces.setArea(area);
	}
	System.out.println(historicalPlaces);
	ContactPerson contactPerson = new ContactPerson();
	contactPerson.setName(name);
	contactPerson.setMobileNumber(mobileNumber);
	System.out.println(contactPerson);
	guide.setName(name);
	guide.setMobileNumber(mobileNumber);
	guide.setCountry(country);
	guide.setState(state);
	guide.setCity(city);
	guide.setArea(area);
	guideList.add(guide);
	guide.setHistoricalPlace(historicalPlaces);
	System.out.println(guideList);
	historicalPlaces.setGuide(guideList);
	historicalPlaces.setContactPerson(contactPerson);
	//Guide guides = historicalPlaceService.registerGuide(guide);
	HistoricalPlace historicalPlaceOne = historicalPlaceService.addHistoricalPlace(historicalPlaces);
return new ModelAndView("success","key",historicalPlaceOne);
	//return new ModelAndView("guides");
}*/

