package com.cg.historicalplaceguidespringmvc.service;

import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.historicalplaceguidespringmvc.controller.HistoricalPlaceController;
import com.cg.historicalplaceguidespringmvc.dao.HistoricalPlaceRepository;
import com.cg.historicalplaceguidespringmvc.dto.ContactPerson;
import com.cg.historicalplaceguidespringmvc.dto.Guide;
import com.cg.historicalplaceguidespringmvc.dto.HistoricalPlace;
import com.cg.historicalplaceguidespringmvc.exception.GuideNameNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceException;
/**@Author JayalakshmiNarayanasamy
 * write on 20-05-2019
 * lastModified 21-05-2019
 * Class used to perform Business Logic and Interact with HistoricalPlaceRepository.
 */
@Service
@Transactional
public class HistoricalPlaceServiceImpl implements HistoricalPlaceService {
	@Autowired
	HistoricalPlaceRepository historicalPlaceRepo;
	/**
	 * @Author JayalakshmiNarayanasamy
	 * write on 20-05-2019
	 * lastModified 21-05-2019
	 * methods addHistoricalPlace add the historical Place
	 * @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
	 * @return HistoricalPlace
	 */
	
	@Override
	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
		
		if(HistoricalPlaceController.logger.isDebugEnabled()) {
			HistoricalPlaceController.logger.debug("addHistoricalPlace (HistoricalPlace) is executed!");
			HistoricalPlaceController.logger.debug(" Id \"+h_id+\" set to HistoricalPlace object\"");
		}
		return historicalPlaceRepo.save(historicalPlace);
	}
/**@Author JayalakshmiNarayanasamy
 * write on 20-05-2019
 * lastModified 21-05-2019
 * (non-Javadoc)
 * @see com.cg.historicalplaceguidespringmvc.service.HistoricalPlaceService#searchByHistoricalPlaceCity(java.lang.String)
 *  @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceCityNotFound
 *  @return  List<HistoricalPlace> details
 */
	@Override
	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound {
		
		if(HistoricalPlaceController.logger.isDebugEnabled()) {
			HistoricalPlaceController.logger.debug("searchByHistoricalPlaceCity (HistoricalPlace) is executed!");
			HistoricalPlaceController.logger.debug(" City \"+city+\" search to HistoricalPlace object\"");
		}
		List<HistoricalPlace> place = historicalPlaceRepo.findByHistoricalPlaceCity(city);
		if (place.isEmpty())
			throw new HistoricalPlaceCityNotFound("Historical Place City Not Found");
		else {
			return place;
			
		}
		
		//return historicalPlaceRepo.findByHistoricalPlaceCity(city);
	}
/**@Author JayalakshmiNarayanasamy
 * write on 20-05-2019
 * lastModified 21-05-2019
 * (non-Javadoc)
 * @see com.cg.historicalplaceguidespringmvc.service.HistoricalPlaceService#assignContactPerson(com.cg.historicalplaceguidespringmvc.dto.ContactPerson)
 *  @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
 *  @returns ContactPerson
 */
	@Override
	public ContactPerson assignContactPerson(ContactPerson contactPerson) {
		if(HistoricalPlaceController.logger.isDebugEnabled()) {
			HistoricalPlaceController.logger.debug("assignContactPerson (HistoricalPlace) is executed!");
			HistoricalPlaceController.logger.debug(" MobileNumber \"+mobileNumber+\" set a HistoricalPlace Object \"");
		}
		return contactPerson;
	}
/**@Author JayalakshmiNarayanasamy
 * write on 20-05-2019
 * lastModified 21-05-2019
 * (non-Javadoc)
 * @see com.cg.historicalplaceguidespringmvc.service.HistoricalPlaceService#registerGuide(com.cg.historicalplaceguidespringmvc.dto.Guide)
 *  @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
 *  @returns guides
 */
	@Override
	public Guide registerGuide(Guide guide) throws HistoricalPlaceException {
		if(HistoricalPlaceController.logger.isDebugEnabled()) {
			HistoricalPlaceController.logger.debug("registerGuide (HistoricalPlace) is executed!");
			HistoricalPlaceController.logger.debug(" City \"+city+\" set to Guide object\"");
		}
		return historicalPlaceRepo.saveGuide(guide);
	}
/**@Author JayalakshmiNarayanasamy
 * write on 20-05-2019
 * lastModified 21-05-2019
 * (non-Javadoc)
 * @see com.cg.historicalplaceguidespringmvc.service.HistoricalPlaceService#searchHistoricalPlaceAreaByGuideName(java.lang.String)
 *  @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
 *  @returns list of historicalPlace
 */
	@Override
	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name) throws GuideNameNotFound {
		if(HistoricalPlaceController.logger.isDebugEnabled()) {
			HistoricalPlaceController.logger.debug("searchHistoricalPlaceAreaByGuideName (HistoricalPlace) is executed!");
			HistoricalPlaceController.logger.debug(" Name \"+name+\" set to HistoricalPlace object\"");
		}
		List<HistoricalPlace> area = historicalPlaceRepo.findHistoricalPlaceAreaByGuideName(name);
		if (area.isEmpty())
			throw new GuideNameNotFound("Guide Name Not Found ");
		return area;
	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*@Autowired
	HistoricalPlaceRepository repo;

	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace) throws HistoricalPlaceException {
		return repo.save(historicalPlace);
	}
 @Author JayalakshmiNarayanasamy
 *  lastModified 16-05-2019
 * This assigncontactPerson method assign the contact person detail to the historical place.
 * (non-Javadoc)
 * @see com.cg.historicalplaceguide.service.HistoricalPlaceService#assignContactPerson(com.cg.historicalplaceguide.dto.ContactPerson)
 
	public ContactPerson assignContactPerson(ContactPerson contactPerson) {
		return contactPerson;
	}

	
	 * Register Guide() method used to store multiple guides in the Historicalplace
	 * (non-Javadoc)
	 * @see com.cg.historicalplaceguide.service.HistoricalPlaceService#registerGuide(com.cg.historicalplaceguide.dto.Guide)
	 
	public Guide registerGuide(Guide guides) throws HistoricalPlaceException {
		Guide guide =repo.saveGuide(guides);
		if(guide==null) {
			throw new HistoricalPlaceException("There is no such Historical place found for this guide");
		}
		return guide;
}

 * SearchHistoricalplacecity method search the historical place city and return the
 *  historical place details and Guide Details.
 * (non-Javadoc)
 * @see com.cg.historicalplaceguide.service.HistoricalPlaceService#searchByHistoricalPlaceCity(java.lang.String)
 
	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city) throws HistoricalPlaceCityNotFound {
		List<HistoricalPlace> place = repo.findByHistoricalPlaceCity(city);
		if (place.isEmpty())
			throw new HistoricalPlaceCityNotFound("Historical Place City Not Found");
		else {
			return place;
			
		}
		
	}

	
	 * @Author JayalakshmiNarayanasamy
 *  lastModified 16-05-2019
	 * searchHistoricalPlaceAreaByGuideName method search the guide name and returns the
	 *  historical place details for the registered guide.
	 * (non-Javadoc)
	 * @see com.cg.historicalplaceguide.service.HistoricalPlaceService#searchHistoricalPlaceAreaByGuideName(java.lang.String)
	 
	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name) {
		List<HistoricalPlace> area = repo.findHistoricalPlaceAreaByGuideName(name);
		if (area.isEmpty())
			throw new HistoricalPlaceException("Guide Name Not Found ");
		return area;
	}

}
*/