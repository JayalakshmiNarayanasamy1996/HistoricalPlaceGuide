package com.cg.historicalplaceguidespringmvc.dto;


import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author Jayalakshmi Narayansamy
 * write on 20-05-2019
 * last Modified 21-05-2019
 * class HistoricalPlace declare as entity
 *@returns HistoricalPlace
 * @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException
 */

@Entity
@Table(name="historicalplace")
public class HistoricalPlace {
	@Id
	@Column(name="h_id")
	private Integer h_id;
	@Column(name = "h_country")
	private String country;
	@Column(name = "h_state")
	private String state;
	@Column(name = "h_city")
	private String city;
	@Column(name="h_area")
	private String area;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "c_mobileno")
	private ContactPerson contactPerson;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="historicalPlace",fetch=FetchType.EAGER)
	private List<Guide> guide = new ArrayList<>();

	public HistoricalPlace() {
	}

	

	public Integer getH_id() {
		return h_id;
	}



	public void setH_id(Integer h_id) {
		this.h_id = h_id;
	}



	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public ContactPerson getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(ContactPerson contactPerson) {
		this.contactPerson = contactPerson;
	}

	public List<Guide> getGuide() {
		return guide;
	}

	public void setGuide(List<Guide> guide) {
		this.guide = guide;
	}



	@Override
	public String toString() {
		return "HistoricalPlace [h_id=" + h_id + ", country=" + country + ", state=" + state + ", city=" + city
				+ ", area=" + area + ", contactPerson=" + contactPerson + ", guide=" + guide + "]";
	}



	public HistoricalPlace(Integer h_id, String country, String state, String city, String area,
			ContactPerson contactPerson, List<Guide> guide) {
		super();
		this.h_id = h_id;
		this.country = country;
		this.state = state;
		this.city = city;
		this.area = area;
		this.contactPerson = contactPerson;
		this.guide = guide;
	}

	

	

}
