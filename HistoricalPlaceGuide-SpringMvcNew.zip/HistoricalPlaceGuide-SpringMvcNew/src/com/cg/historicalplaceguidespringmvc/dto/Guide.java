package com.cg.historicalplaceguidespringmvc.dto;


import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @Author Jayalakshmi
 * @Component declare the class as bean
 * @Scope Specifies the scope to use for the annotated component/bean.
	 * @see ConfigurableBeanFactory#SCOPE_SINGLETON
	 * @see ConfigurableBeanFactory#SCOPE_PROTOTYPE
	 * @see org.springframework.web.context.WebApplicationContext#SCOPE_REQUEST
	 * @see org.springframework.web.context.WebApplicationContext#SCOPE_SESSION
	 * @returns guides
	 * @exception com.cg.historicalplaceguidespringmvc.HistoricalPlaceException

 */

@Entity
@Table(name = "guide")
public class Guide {
	@Column(name = "g_name")
	private String name;
	@Id
	@Column(name = "g_mobileno" , nullable = false)
	private BigInteger mobileNumber;
	@Column(name = "g_country")
	private String country;
	@Column(name = "g_state")
	private String state;
	@Column(name ="g_city")
	private String city;
	@Column(name="g_area")
	private String area;
	
	@ManyToOne
	@JoinColumn(name="h_id")
	private HistoricalPlace historicalPlace;

	

	public Guide() {
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public BigInteger getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public String getCountry() {
		return country;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getArea() {
		return area;
	}



	public void setArea(String area) {
		this.area = area;
	}



	public HistoricalPlace getHistoricalPlace() {
		return historicalPlace;
	}



	public void setHistoricalPlace(HistoricalPlace historicalPlace) {
		this.historicalPlace = historicalPlace;
	}



	@Override
	public String toString() {
		return "Guide [name=" + name + ", mobileNumber=" + mobileNumber + ", country=" + country + ", state=" + state
				+ ", city=" + city + ", area=" + area + ", historicalPlace=" + historicalPlace + "]";
	}



	public Guide(String name, BigInteger mobileNumber, String country, String state, String city, String area,
			HistoricalPlace historicalPlace) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.country = country;
		this.state = state;
		this.city = city;
		this.area = area;
		this.historicalPlace = historicalPlace;
	}


}
