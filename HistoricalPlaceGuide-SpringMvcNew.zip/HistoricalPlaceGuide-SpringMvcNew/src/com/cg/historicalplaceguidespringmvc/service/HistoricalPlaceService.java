package com.cg.historicalplaceguidespringmvc.service;

import java.util.List;

import com.cg.historicalplaceguidespringmvc.dto.ContactPerson;
import com.cg.historicalplaceguidespringmvc.dto.Guide;
import com.cg.historicalplaceguidespringmvc.dto.HistoricalPlace;
import com.cg.historicalplaceguidespringmvc.exception.GuideNameNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceCityNotFound;
import com.cg.historicalplaceguidespringmvc.exception.HistoricalPlaceException;
/**
 * @Author Jayalakshmi Narayansamy
 * write on 20-05-2019
 * last Modified 20-05-2019
 * Interface  declare the methods
 * @exception HistoricalPlaceException
 * @returns historicalPlace 
 */
public interface HistoricalPlaceService {
	public HistoricalPlace addHistoricalPlace(HistoricalPlace historicalPlace)throws HistoricalPlaceException;

	public List<HistoricalPlace> searchByHistoricalPlaceCity(String city)throws HistoricalPlaceCityNotFound;

	public ContactPerson assignContactPerson(ContactPerson contactPerson);

	public Guide registerGuide(Guide guide)throws HistoricalPlaceException;

	public List<HistoricalPlace> searchHistoricalPlaceAreaByGuideName(String name)throws GuideNameNotFound;

}
