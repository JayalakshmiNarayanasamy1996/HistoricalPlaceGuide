package com.cg.historicalplaceguidespringmvc.exception;


/**@Author JayalakshmiNarayanasamy
 *  lastModified 20-05-2019
 * GuideNameNotFound will handle the exception
 */

public class GuideNameNotFound extends RuntimeException{
	
	public GuideNameNotFound() {
		
	}
	public GuideNameNotFound(String msg) {
		super(msg);
	}

}
