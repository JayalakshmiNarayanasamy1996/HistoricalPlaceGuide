package com.cg.historicalplaceguidespringmvc.exception;
/**
 * @Author Jayalakshmi Narayanasamy
 * write on 20-05-2019
 * last modified 21-05-2019
 * HistoricalPlaceException will handle the exception
 */
public class HistoricalPlaceException extends RuntimeException {
	public HistoricalPlaceException() {

	}

	public HistoricalPlaceException(String msg) {
		super(msg);
	}

}
