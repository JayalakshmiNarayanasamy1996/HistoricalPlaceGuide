package com.cg.historicalplaceguidespringmvc.exception;
/**
 * @Author JayalakshmiNarayanasamy
 *  lastModified 16-05-2019
 * HistoricalPlaceCityNotFound will handle the exception
 */

public class HistoricalPlaceCityNotFound extends RuntimeException{
	public HistoricalPlaceCityNotFound() {
		
	}
	public HistoricalPlaceCityNotFound(String msg) {
		super(msg);
	}

}
